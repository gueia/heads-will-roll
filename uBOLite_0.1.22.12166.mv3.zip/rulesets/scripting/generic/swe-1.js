/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-generic

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssGenericImport() {

/******************************************************************************/

// swe-1

const toImport = [[3407338,"#_ning_gdpr_approve"],[2640566,"#accept-cookies-div"],[5966067,"#ad-fullscreen:not(body):not(html)"],[16537908,"#ad-mega-container:not(body):not(html)"],[14618602,"#ad-wallpaper:not(body):not(html)"],[14904532,"#ad_topScroller:not(body):not(html)"],[7467429,"#advisa-iframe"],[8397176,"#aloq-cookie-warning"],[12279415,"#annons_head"],[11619812,"#bottomAnnonsBar"],[2340937,"#catapult-cookie-bar"],[5661487,"#cliSettingsPopup.cli-modal"],[9132611,"#colorbox.cookie-info-modal"],[14961625,"#cookie-alert"],[977851,"#cookie-banner"],[12452224,"#cookie-bar"],[581471,"#cookie-consent-banner"],[2489985,"#cookie-info"],[5982062,"#cookie-law-container"],[2489900,"#cookie-line"],[10932404,"#cookie-message"],[983813,"#cookie-notice"],[983833,"#cookie-policy"],[783004,"#cookie-policy-overlay"],[10936388,"#cookie-warning"],[6386027,"#cookie_approve_banner"],[10637445,"#cookie_consent"],[249279,"#cookie_prompt"],[7686891,"#cookieAcceptBar"],[2469789,"#cookieAlert"],[2134623,"#cookiebar"],[16240022,"#cookieChoiceInfo"],[2626976,"#CookieDialog"],[12450371,"#cookieinfo"],[16256628,"#cookieInfoBar"],[5156114,"#CookieInformationDialog"],[2926974,"#cookieInformerBooklet"],[2134359,"#cookiejar"],[419308,"#cookielawwarning"],[9847725,"#cookieMsgBlock"],[14923699,"#cookieNotice"],[2612307,"#CookieNotice"],[1993303,"#cookies-acceptance .alert.bottom"],[2452191,"#cookiesInfo"],[6467540,"#dialog-eu-cookie-law"],[14902916,"#div-leeadsFullpageAd"],[12134901,"#itc-cookie-notify.active"],[8991569,"#js-cookie-section.show"],[5815677,"#klaro .cookie-modal"],[8175970,"#leeads-panorama-container"],[16442444,"#moove_gdpr_cookie_info_bar"],[1285195,"#redim-cookiehint"],[15620377,"#redim-cookiehint-modal"],[9999431,"#RightOuterBannerDiv"],[8830454,"#strossle-below-article-thumbnails"],[11082482,"#topBannerAds"],[8964317,"._ning_outer._ning_jss_zone:not(body):not(html)"],[14542089,".ad-rotator:not(body):not(html)"],[6811294,".ad-single-news:not(body):not(html)"],[12252131,".ad_container_bottom:not(body):not(html)"],[9019188,".adContainer:not(body):not(html)"],[637145,".adrotate-group:not(body):not(html)"],[8812174,".adtoma_container:not(body):not(html)"],[7940887,".adtrue-holder:not(body):not(html)"],[15872750,".annons_mitten:not(body):not(html)"],[3196721,".annons_panorama:not(body):not(html)"],[4722515,".annonseArticle:not(body):not(html)"],[15420235,".b-ad__wrapper:not(body):not(html)"],[2688179,".b-cookies:not(body):not(html)"],[7568749,".bannerclick:not(body):not(html)"],[10913194,".c-ad-wrapper:not(body):not(html)"],[622414,".c-ad__floating:not(body):not(html)"],[4009266,".c-cookies.is-active:not(body):not(html)"],[3706626,".c-dfp_ads:not(body):not(html)"],[6418664,".c-post--native-ad:not(body):not(html)"],[9021974,".carrie-ad-block:not(body):not(html)"],[4585392,".casino-ad:not(body):not(html)"],[8618236,".category-annons:not(body):not(html)"],[12249051,".category-annonssamarbete:not(body):not(html)"],[425946,".category-om-samarbeten:not(body):not(html)"],[8385744,".category-samarbeten:not(body):not(html)"],[3259852,".category-sponsrad-artikel:not(body):not(html)"],[10279767,".category-sponsrad:not(body):not(html),.category-sponsrat:not(body):not(html)"],[3260573,".category-sponsrade-inlagg:not(body):not(html)"],[4147035,".category-sponsrade-reklaminlagg:not(body):not(html)"],[3243166,".category-sponsrat-content:not(body):not(html)"],[7558646,".category-sponsrat-inlagg:not(body):not(html)"],[13928613,".category-sponsrat-innehall:not(body):not(html)"],[1779092,".cc-banner.cc-bottom:not(body):not(html)"],[1801534,".cc-grower:not(body):not(html)"],[1770707,".cc-window.cc-floating:not(body):not(html)"],[7483090,".component-matchAds:not(body):not(html)"],[1243899,".component-matchAds__content:not(body):not(html)"],[177174,".Cookie-banner.is-open:not(body):not(html)"],[4720826,".cookie-consent:not(body):not(html)"],[11156680,".cookie-notice:not(body):not(html)"],[9104223,".cookie-notification:not(body):not(html)"],[13609647,".cookie__wrapper:not(body):not(html)"],[2235913,".cookie_consent_bar:not(body):not(html)"],[4326766,".cookie_popup_box:not(body):not(html)"],[11895866,".cookieConsent:not(body):not(html)"],[4858774,".dfp-ad-widget-class:not(body):not(html)"],[11129728,".dj-ad-size:not(body):not(html)"],[15934937,".esmg-hb-slot:not(body):not(html)"],[12482740,".favethemes-content-ad-bottom:not(body):not(html)"],[12482732,".favethemes-content-ad-inline:not(body):not(html)"],[6374869,".favethemes-content-ad-top:not(body):not(html)"],[16770867,".footer-ad-wrap:not(body):not(html)"],[7781282,".gdpr-banner:not(html):not(body)"],[6063330,".js-cookie-disclaimer:not(body):not(html)"],[1516748,".js-cookie-warning:not(body):not(html)"],[12581098,".layerAdContainer:not(body):not(html)"],[10548519,".lazyb.panorama"],[14251286,".leeads-advert:not(body):not(html)"],[1037838,".loop-mobile-leeads:not(body):not(html)"],[4360639,".mittenannons:not(body):not(html)"],[11554168,".node-sponsored-article:not(body):not(html)"],[72420,".nyhet_wrapper_annons:not(body):not(html)"],[9897668,".o-cookie-bar:not(body):not(html)"],[4574715,".o-grid__ad-column:not(body):not(html)"],[2610898,".p-cookie-prompt.-display:not(body):not(html)"],[6787489,".penci-adsense-below-slider:not(body):not(html)"],[972506,".penci-infeed-fullwidth-ads:not(body):not(html)"],[5618037,".plista_widget_outstream:not(body):not(html)"],[2757487,".react-ad:not(body):not(html)"],[6859378,".rmss_main-ad:not(body):not(html)"],[7998147,".sponsorBanner:not(body):not(html)"],[15352291,".sponsrad-artikel:not(body):not(html)"],[4692695,".stampenCookieContainer:not(html):not(body)"],[15579121,".sw-popular__article--ad:not(body):not(html)"],[1972431,".sw-sponsored_post:not(body):not(html)"],[14569690,".sw-tag-sponsored_post:not(body):not(html)"],[11488067,".swp-ad-strossle:not(body):not(html)"],[5729759,".tag-sponsrat-inlagg:not(body):not(html)"],[12956611,".teaser--native-ad:not(body):not(html)"],[10229390,".Teaser--nativeAd:not(body):not(html)"],[10679288,".thb_ad_header:not(body):not(html)"],[2092162,".toppannonser:not(body):not(html)"],[4312692,".widget_adonnews:not(body):not(html)"],[112794,".widget_eu_cookie_law_widget:not(body):not(html)"],[13508738,".widget_ev_ad_widget:not(body):not(html),.widget_ic_ad_widget:not(body):not(html)"]];

const genericSelectorMap = self.genericSelectorMap || new Map();

if ( genericSelectorMap.size === 0 ) {
    self.genericSelectorMap = new Map(toImport);
    return;
}

for ( const toImportEntry of toImport ) {
    const existing = genericSelectorMap.get(toImportEntry[0]);
    genericSelectorMap.set(
        toImportEntry[0],
        existing === undefined
            ? toImportEntry[1]
            : `${existing},${toImportEntry[1]}`
    );
}

self.genericSelectorMap = genericSelectorMap;

/******************************************************************************/

})();

/******************************************************************************/
