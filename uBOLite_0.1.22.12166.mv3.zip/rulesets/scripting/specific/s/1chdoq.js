/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// deu-0

const argsList = [{"a":".bscb-23811,\n.irypolkj,\n.zekfylmnsq"},{"a":".tritime-ads-middle"},{"a":".first_slot,\n.second_slot"},{"a":".sponsors-slider"},{"a":".sponsorftr"},{"a":".stream-item,\n.stream-item-widget"},{"a":"#g-expanded,\n#g-header"},{"a":"#tvd-ad-top"},{"a":".cont-60"},{"a":".floatLeft[style=\"padding:10px;\"]"},{"a":".button.affiliate,\n.promo-box-any-banner"},{"a":".tfm-banner"},{"a":".tvg-manager-box"},{"a":"a[href^=\"https://www.tweakpc.de/rev3/www/delivery/\"]"},{"a":".chemical_sitelogo_r"},{"a":"table[style=\"background-color: none; border-top: 1px dashed; border-color: #a89058; border-left: 1px dashed; border-color: #a89058; border-right: 1px dashed; border-color: #a89058; border-bottom: 1px dashed; border-color: #a89058;\"]"},{"a":"#custom_html-107,\n#custom_html-110,\n#custom_html-77,\n#custom_html-88,\n#custom_html-95,\n#custom_html-97,\n.flexslider,\na[href^=\"https://www.amazon.\"][href*=\"tag=\"] > img"},{"a":"#shuffled-sponsored,\n#sidebar_container"},{"a":"#wrapper-banner-head"},{"a":".mh-footer"},{"a":".channel-logo-desc"},{"a":".vm-banner"},{"a":".header-right"},{"a":".vc_custom_1544363997968,\nimg[width=\"110\"]"},{"a":"#sponsor-footer"},{"a":".partners-footer"},{"a":".YouTubeDachstein,\n.YouTubeLEKI,\n.YouTubeoetz,\ndiv[class^=\"overlay-\"]"},{"a":"#skypos,\n.rcu,\n.rec"},{"a":".vip-medium-rectangle,\n.vip-teaser"},{"a":".quartermedia,\nkas[type=\"placement\"]"},{"a":"#partnerLinks"},{"a":"div[id^=\"findexp-\"]"},{"a":"#dcb1,\n#dcb2,\n#fullsizeBanner1,\n#mooTicker,\n#mooTickerContainerMobile,\n.partnerNews > a[target=\"_blank\"],\n.sb_popularleverageproducts,\n.sb_quotebox,\n.shareInFocus,\n.teaser.objectfit:has(div.anzeige),\na[href^=\"https://smartbroker.de/\"][href*=\"/?utm_\"],\na[href^=\"https://smartbroker.de/?utm_source=\"],\na[href^=\"https://www.etracker.de/ccr?\"],\na[onclick*=\"'tableAd'\"],\na[onclick*=\"'tableAd'\"] + img"},{"a":".teaserheld-wrapper"},{"a":"#service-middle"},{"a":".iba-variant-test,\n.partner-links,\ndiv[data-adservice-slot],\ntr[data-component=\"MessageListAdRow\"]"},{"a":"#addmeright,\n#addmetop"},{"a":"#weekli-interstitial"},{"a":"aside[id^=\"banner\"],\ndiv[style*=\"display: block ! important\"],\ndiv[style=\"position:absolute; top:5px; left:0px; text-align:center; width:100%; max-width:1000px; height:90px; overflow:hidden;\"]"},{"a":".guj-ad-slot"},{"a":"table[width=\"738\"][height=\"90\"]"},{"a":"#woFooterBillboard"},{"a":".clicked_partner"},{"a":"#SP-commercials"},{"a":"#text-html-widget-15"},{"a":"#block-views-sponsoredcontent-block,\n#block-views-sponsoredpromo-block,\ndiv[id^=\"gWrapper-\"],\niframe[style=\"height:250px;overflow: hidden;\"]"},{"a":"#g_content_recommendation,\n#homepage_rectangle,\n#wfv4_bb2_lazyload[style=\"min-height:250px\"],\n.amazon_widget_w660,\n.mb25[style=\"min-height:261px\"],\n.news330.floatL.mr10:has(.anzeige),\n.ob_what,\n.primis_widget,\n.rutschdiv,\ndiv[align=\"center\"][style=\"min-height: 320px;\"],\ndiv[style=\"margin: 3px 0px; text-align: center; min-width: 300px; min-height: 250px;\"],\ndiv[style=\"min-width: 300px; min-height: 250px;\"],\ndiv[style=\"width:670px;height:280px;\"]"},{"a":".wf_gcsi"},{"a":"#topads"},{"a":"img[width=\"140\"][height=\"180\"]"},{"a":".block-wissen-ads,\n.node-promoted"},{"a":".code-block-13"},{"a":".client_wrapper"},{"a":".amazon-search"},{"a":".widget__image--banner"},{"a":".logo-slider"},{"a":"#outerBoxStart"},{"a":".vc_custom_1623308998554"},{"a":".sa2,\n.sa2_top"},{"a":".spielen_kopf"},{"a":"#offer"},{"a":"div[id^=\"aktue-\"]"},{"a":".zett-teaser-trio:has(.zett-teaser-trio__kicker--ad-anzeige)"},{"a":"#slot__header,\n.products-inarticle-slider--parent"},{"a":".logo_rechts_mitte"},{"a":".witz > .bewertung + .detaillink + p:last-child,\n.witz > .bewertung + p:last-child"},{"a":"#block-block-14,\n#footer-banner-frame"},{"a":".topRight300x250"},{"a":".component-code-snippet"},{"a":"#custom_html-22"},{"a":"#_mo_cti,\n._mo_recs,\n.no-baldomero,\n.publi_cabecera_270,\n.publi_mega"},{"a":"#dish-top-desktop"},{"a":"#media_image-23"},{"a":"img[height=\"600\"]"},{"a":"img[width=\"600\"]"},{"a":".support_banner_lead"},{"a":"#divi_pb_widget-3"},{"a":".buy"},{"a":"#sidebar-sponsor,\n.widget-list-sponsors"},{"a":"#sponsors-tablet,\n.sponsors-desktop"},{"a":".hirdetes"},{"a":"#nav_menu-2"},{"a":".r"},{"a":".sidebar"},{"a":"#chati_frame,\n#spezial_column,\n#wb_widget,\n.size-300x250,\n.spz_height_60"},{"a":"#BelowRectangle"},{"a":"div[class^=\"runds-werbung-\"]"},{"a":".owl-carousel"},{"a":"#custom_html-121,\n#custom_html-126,\n#custom_html-127,\n#custom_html-132,\n#custom_html-143,\n#custom_html-144,\n#custom_html-145,\n#desktop_understitial,\n#halfpage,\n#media_image-10,\n#rectangle,\n#top_0,\na[href*=\".rokkr.net/promo/\"],\na[href*=\"/hide.me/de/?friend=\"],\na[href*=\"/prf.hn/click/\"],\na[href*=\"?sca_ref=\"],\na[href^=\" https://www.bit.ly/\"],\na[href^=\"https://hide.me/de/promotion/\"],\ndiv[style=\"width:300px;height:250px\"]"},{"a":".dt"},{"a":".supporter"},{"a":".page-banner"},{"a":".bxslider,\n.partvert-right"},{"a":"a[id=\"bottombanner\"]"},{"a":".mainSponsor,\n.sportnews"},{"a":".werb"},{"a":".sponsorslider"},{"a":".qodef-e-logo > img[height=\"80\"]"},{"a":".w-header"},{"a":".add"},{"a":".slideshowck"},{"a":".divAdd_Banner"},{"a":".custom-ban-wrap"},{"a":"#header-wrapper + div[class=\"row \"],\n.ad-listing,\narticle[id^=\"post-\"]:has(.sponsored-indicator)"},{"a":".teaser--sponsored"},{"a":"aside:has(img[src*=\"/adverts/\"])"},{"a":".banPlace1,\n.banner_sidebar"},{"a":".mdhRegister-btn"},{"a":"#head_banner,\n#pis_posts_in_sidebar-6,\n#widget_sp_image-14"},{"a":"#superreplacement"},{"a":"a[href^=\"https://www.banggood.com/marketing-\"]"},{"a":"#topBanner"},{"a":"#forumbanner"},{"a":"#dnvsuperbanner"},{"a":"#adunit"},{"a":".commercialbar,\n.top_bannerbar"},{"a":"#billboard_btf_2,\n#footer-ad,\n#news-contentads,\n#sticky-superbanner,\n#ubs-banner-fallback,\n.adsbygoogle,\n.cpg_incontent1-container,\n.cpg_incontent2-container,\n.mleft-10 + .table-quotes,\n.mrec-height-prefix,\n.row.d-flex.align-items-center:has(a[href^=\"http://g.finanzen.net/allvest-fonds-home-intelligent-invest\"]),\na[href=\"#p500Werbehinweis\"],\na[href=\"http://g.finanzen.net/ubs-aktiendetail-hebel-fallback\"],\na[href^=\"http://g.finanzen.net/bs-anlegerclub\"],\na[href^=\"http://g.finanzen.net/hsbc-startseite-top-flop?id=\"],\na[href^=\"http://g.finanzen.net/premium-teaser-bnp\"],\na[href^=\"https://ad.doubleclick.net/\"],\narticle.page-content__item:has(img[alt=\"UBS\"]),\nimg[alt=\"Passende Produkte von Vontobel\"],\nimg[alt=\"Passende Produkte von der Société Générale\"]"},{"a":"#nab_container"},{"a":".field--name-dynamic-token-fieldnode-wett-tipps-4-wettanbieter-h2 + .field--name-dynamic-block-fieldnode-top-3-anbieter"},{"a":"#ai_widget-5,\n#text-6"},{"a":"._bb_1,\n._gartenjournal_billboard,\n._gartenjournal_inarticle_2,\n._gartenjournal_leaderboard_oben,\n._gartenjournal_leaderboard_unten,\n.adinj"},{"a":".atkp-container"},{"a":".pane-dpipub-rossel-imu-middle-moblile,\n.pane-dpipub-rossel-native-top,\ndiv[class^=\"pane-dpipub-\"]"},{"a":".rectangles-row"},{"a":"#page-header + br + .forabg"},{"a":"div[style^=\"width:300px;height:250px;\"]"},{"a":".content-main-box-300x250,\n.content-main-box-728x90,\n.content-right-box-300x250right"},{"a":".netpoint"},{"a":".noprint > div[style] + div[style] > script:first-child + div[style]:last-child"},{"a":".gstsk"},{"a":"td:nth-of-type(3):not(:last-of-type) table[width^=\"3\"]"},{"a":"#as2931,\n.pi-banner,\na[href^=\"https://www.fincabayano.net/\"]"},{"a":".funbox"},{"a":".code-block-12,\n.code-block-14,\n.code-block-h-250px,\n.code-block-h-300px,\ndiv[style=\"height: 300px;\"]"},{"a":"#catfad"},{"a":"#wa_join_btn,\na[href^=\"http://www.livestrip.com/FreeAccountLanding.aspx?\"]"},{"a":"#subheader"},{"a":"#Layer1,\n#Layer2"},{"a":".header-promo"},{"a":"#banners,\ndiv[style=\"float:right; width: 110px; margin-left: 15px; margin-top: 12px; margin-bottom: 15px; padding: 2px 6px; text-align: center; border: 1px solid black; background:white; line-height: 2em; color: black;\"]"},{"a":".widget_atkp_widget"},{"a":"a[href^=\"http://camgirly.net\"]"},{"a":"#centcon-side-inner"},{"a":".azk-native-responsive"},{"a":"#leaderwidget"},{"a":".googlediv"},{"a":".adb"},{"a":".amz"},{"a":".zitat > div[style=\"width:300px;\"]"},{"a":".e_adv"},{"a":"div[id^=\"modifiedwerbung_\"]"},{"a":"div[style=\"height: 280px; margin: 5px 0 5px 0;\"]"},{"a":"#ny_banner,\n#right160x600,\n.googl,\n.recommend,\n.right > .widgetbox2,\ndiv[style=\"height:90px;overflow:hidden;text-align:center;\"]"},{"a":"a[href=\"http://topne.ws/onlineoutlet\"]"},{"a":"#parcello-mo"},{"a":"#wn-insurance-quote-editor"},{"a":"#gad-sky,\n#gads-leaderboard,\n.pane-aktuelle-top-links"},{"a":".zenoLSInnerProductTableRightAmazon"},{"a":"#custom_post_widget-6"},{"a":"#premium-partners"},{"a":"div[id^=\"edit\"][style=\"padding:0px 0px 6px 0px\"] > table[id^=\"post\"][width=\"100%\"][cellspacing=\"0\"][cellpadding=\"6\"][border=\"0\"][align=\"center\"] + br + .tborder[width=\"100%\"][cellspacing=\"0\"][cellpadding=\"6\"][border=\"0\"][align=\"center\"]"},{"a":".d_695692"},{"a":"a[href^=\"http://filestore.to/premium\"]"},{"a":".Banner"},{"a":"#selfpromotionOverlay"},{"a":".d_702192"},{"a":".dl2019main,\n.top2019main"},{"a":"a[href*=\"/af.php\"]"},{"a":"a[href^=\"//fbmedia-ckl.com/\"]"},{"a":"#ni-overlay"},{"a":".d_702232"},{"a":"a[href^=\"https://lp.mydirtyhobby.com/\"]"},{"a":".d_702212"},{"a":".top_news_adv"},{"a":".fixed.bottom-0.pb-8"},{"a":".sdtv-gothaer"},{"a":"a[href^=\"https://hoerbuch.us/dll/\"],\na[href^=\"https://linksnappy.com/?ref=\"],\na[href^=\"https://www.purevpn.com/?aff=\"],\na[href^=\"https://www.purevpn.com?aff=\"]"},{"a":".tftable"},{"a":"#block-anzeige,\n.region-topad"},{"a":"a[href^=\"//plx.hammerporno.xxx/pool_link/\"]"},{"a":"#unten_anzeigen"}];

const hostnamesMap = new Map([["tri-mag.de",0],["tritime-magazin.de",1],["trvlcounter.de",2],["tsg-hoffenheim.de",3],["tsv1860.de",4],["tutonaut.de",5],["tv-huettenberg.de",6],["tvdigital.de",7],["tvg-grosssachsen.de",8],["tvinfo.de",9],["tvspielfilm.de",10],["m.tvspielfilm.de",11],["tvsportguide.de",12],["tweakpc.de",13],["typo3blogger.de",14],["ubuntu-forum.de",15],["uepo.de",16],["uhrforum.de",17],["unicum.de",18],["unterwasserwelt.de",19],["utopia.de",20],["velomotion.de",21],["verlagshaus-jaumann.de",22],["vfl.de",23],["vfl-gummersbach.de",24],["vfl-wolfsburg.de",25],["via-ferrata.de",26],["videoaktiv.de",27],["vip.de",28],["vital.de",29],["volleyball-bundesliga.de",30],["vrnerds.de",31],["wallstreet-online.de",32],["watson.de",33],["web.de",[34,35]],["gmx.net",35],["webwiki.de",36],["weekli.de",37],["weristdeinfreund.de",38],["wetter.de",39],["wetterbote.de",40],["wetteronline.de",41],["wg-gesucht.de",42],["wiesbaden.de",43],["windowspower.de",44],["windowspro.de",45],["winfuture.de",46],["winfuture-forum.de",47],["wintotal.de",48],["wirsiegen.de",49],["wissen.de",50],["wohnungswirtschaft-heute.de",51],["fussballnationalmannschaft.net",[51,119]],["wolfsrevier.de",52],["forum.worldofplayers.de",53],["wp-koenigin.de",54],["wohnidee.wunderweib.de",55],["xgadget.de",56],["xn--schne-aussicht-xpb.de",57],["xn--solitr-fua.de",58],["xn--spidersolitr-qcb.de",59],["yasni.de",60],["yoga-aktuell.de",61],["zeit.de",62],["zentrum-der-gesundheit.de",63],["zfans.de",64],["zitate-online.de",65],["zum.de",66],["zumfahren.de",67],["nordschleswiger.dk",68],["andalusien-aktuell.es",69],["mallorcazeitung.es",70],["kalender-365.eu",71],["mdz-moskau.eu",72],["quadjournal.eu",73],["silentworld.eu",74],["vanion.eu",75],["connectiv.events",76],["lounge.fm",77],["primeleague.gg",78],["uniliga.gg",79],["budapester.hu",80],["balaton-zeitung.info",81],["codecheck.info",82],["german-porno-deutsch.info",83],["hd-pornos.info",84],["pornoente.tv",84],["mazda-forum.info",85],["rundschau.info",86],["ssv-brixen.info",87],["tarnkappe.info",88],["bolzano-bozen.it",89],["broncos.it",90],["kultur.bz.it",91],["dererker.it",92],["dervinschger.it",93],["hceppan.it",94],["sbb.it",95],["nydus.org",[95,152]],["sportclub-meran.it",96],["ssvbozenhandball.it",97],["stol.it",98],["suedtiroltv.it",99],["wallis24.it",100],["volksblatt.li",101],["filmstreaming-de.life",102],["diegrenzgaenger.lu",103],["wort.lu",104],["az.com.na",105],["archzine.net",106],["aus-liebe.net",107],["belgieninfo.net",108],["chilloutzone.net",109],["chinahandys.net",110],["otr.datenkeller.net",111],["dforum.net",112],["dnv-online.net",113],["g.doubleclick.net",114],["edelsteine.net",115],["sternzeichen.net",115],["finanzen.net",116],["fupa.net",117],["fussballinfo.net",118],["gartenjournal.net",120],["gartenratgeber.net",121],["grenzecho.net",122],["hifistatement.net",123],["hstt.net",124],["italienisch-lernen-online.net",125],["kostenlosspielen.net",126],["lavendel.net",127],["mikrocontroller.net",128],["my-homo.net",129],["pesterlloyd.net",130],["pi-news.net",131],["raidrush.net",132],["raptastisch.net",133],["sexei.net",134],["sexfilmegratis.net",135],["sexvideoskostenlos.net",135],["sims-3.net",136],["staedte-info.net",137],["taucher.net",138],["breakpoint.untergrund.net",139],["usa-info.net",140],["zensiert.net",141],["polizei.news",142],["abmahnung.org",143],["anime-loads.org",144],["dejure.org",145],["fairytail-tube.org",[146,147]],["naruto-tube.org",146],["german-bash.org",148],["metropolico.org",149],["modified-shop.org",150],["n-mag.org",151],["outleter.org",153],["parcello.org",154],["travelguide-en.org",155],["tschechien-online.org",156],["zeno.org",157],["wochenblatt.pl",158],["wein.plus",159],["boerse.sx",160],["goldesel.sx",[161,162]],["blockbuster.to",[162,165]],["laden.to",[162,170]],["saugen.to",[162,172]],["blackdevils.team",163],["darkpantersclan.de.tl",164],["gload.to",166],["hd-source.to",167],["kinoger.to",168],["kinomax.to",169],["pornkinox.to",171],["xrel.to",173],["fight24.tv",174],["sportdeutschland.tv",175],["hoerbuch.us",176],["kinox-filme.work",177],["jungle.world",178],["hammerporno.xxx",179],["wildesporno.xxx",180]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
