/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// rus-0

const argsList = [{"a":".layout > div[class^=\"top\"],\n.unit_main-banner_right"},{"a":"div[style][onclick*=\"/rizni/\"]"},{"a":".gd,\n.inad"},{"a":"#app-view > script + .row > article ~ .col-md-3,\n.banner-widget,\n.mt-10 > a[href][rel=\"nofollow\"]"},{"a":".td-ss-main-content > div[style=\"margin-top: 40px;\"] ~ *"},{"a":"a[href^=\"http://creditka.kiev.ua\"]"},{"a":"td[width=\"245\"][align=\"left\"][valign=\"top\"] > div[style^=\"height:\"]"},{"a":".divider,\n.sidebar-right"},{"a":"#ad_pu_modal,\n:not(html) > iframe[style*=\"important\"]:not([src^=\"https://disqus.com/embed/comments/\"]),\ndiv[id^=\"ad_center\"],\ndiv[id^=\"ads\"]"},{"a":".cp-modal-popup-container"},{"a":"#rightCommercial"},{"a":"a[href*=\"://opillia.com/\"]"},{"a":"img[src*=\"/partner/images/\"]"},{"a":".tab_text > form a[href][target=\"_blank\"]"},{"a":".penci-sidebar-widgets.widget-area-2,\ndiv[class^=\"c40-reveal-modal\"]"},{"a":".artbanner,\n.kom,\n.wrapbanner"},{"a":".divBanners"},{"a":".slider_big"},{"a":".header_rec"},{"a":".postabove,\np:has( > strong ~ a[href*=\"://blockads.\"])"},{"a":".favorites-block__list"},{"a":"#top-categories-autoscroll > #main-autoscroll"},{"a":"a[href*=\"/php/rotator/goto.php?id=\"]"},{"a":"[class^=\"headerBanner\"] > .top"},{"a":"div[id^=\"baner\"]"},{"a":".rau-header-slider-wrap"},{"a":".rdblock"},{"a":".adw-link"},{"a":"article > .box[style=\"width:fit-content\"]"},{"a":".aside-column > a > img[src*=\"/home/banners/\"]"},{"a":"[id^=\"rst-page-banner-300x250\"]"},{"a":".sidebar-widgets > .widget_text,\n.spu-bg,\n.spu-box"},{"a":"a.info[href][target=\"_blank\"]"},{"a":"#page-header > .panel,\n.headerbar > .inner > div[style=\"float:right\"]"},{"a":"[class*=\"billboard\"]"},{"a":"#head--area,\n.ablock,\ndiv[class^=\"sed\"] > .half.left > .sdbrick:nth-child(-1n+9),\ndiv[class^=\"sed\"] > .half.right > .sdbrick,\ndiv[class^=\"sed\"] > a[rel=\"nofollow\"]"},{"a":".article__adml"},{"a":".article__banner-container"},{"a":".b-widget__rates"},{"a":".box__sponsor,\n.section-spr"},{"a":".box:has( > .box__sponsor),\n.branding-under-menu,\n.lifescore__scroll"},{"a":".mfp-bg"},{"a":"#adsLeftZone,\n#rightCol,\n.informerTop,\n.rightAdvBox,\ndiv[style^=\"margin\"][style$=\"width: 300px;\"]"},{"a":"[class^=\"branding-link-\"]"},{"a":"#videos-ads,\ndiv[id^=\"premium-banner\"],\ndiv[id^=\"topbanner\"]"},{"a":"#b_sport_240,\n#bann-240,\n#news_text > div[class]:has(table[cellpadding] a[target=\"_blank\"]),\n#news_text > p:has( > a[href*=\"://analyticsq1.com/\"]),\n.right-top__banner,\n.sportua-bet-block,\na[href*=\"clickstats.fun\"],\na[href*=\"favbet\"][target=\"_blank\"],\ndiv[id^=\"b_sport_\"],\ndiv[id^=\"zone_\"],\nimg[src=\"https://pic.sport.ua/images/media/orig/f2/16364.gif\"]"},{"a":".partners-block"},{"a":".video-banner"},{"a":".bottom > .bnr"},{"a":".bnr-wrapper"},{"a":"aside > .w-nt.primary-sidebar-widget"},{"a":".Notices.PanelScroller"},{"a":".category-card__card-row > .col:has( > div > .tabletki-adunit),\n.com__panel-header"},{"a":".csa-head"},{"a":"#popup-root"},{"a":"#Flash"},{"a":"#header > .rounded"},{"a":".partners-news"},{"a":".banner-wide"},{"a":"a[href*=\"brendi\"][target=\"_blank\"],\na[href][target=\"_blank\"][style*=\"/media/uploads/\"]"},{"a":".c-aside__port,\n.c-section > .l-row > .l-col:has( > [data-ad-container]),\niframe[src*=\"/partner-news?\"],\nmain > aside.u-divider--t:has( > iframe[src*=\"/partner-news?\"])"},{"a":"#salut_splash"},{"a":".banner_white"},{"a":".partners-block-wrapper"},{"a":".aside-gab,\n.gab-ins,\ndiv[class^=\"ab_premium_\"]"},{"a":".empty_block,\n.home_ad_first_screen,\ndiv[class^=\"adubr\"]"},{"a":".main_brand_link"},{"a":".fancybox-lock .fancybox-overlay"},{"a":".val-external__top-banner,\n.val-sidebar"},{"a":".authorSingleBlock,\n.mainBlockAds,\n.vestiAds,\n.vestiTiserAds,\nheader > a[href] > img"},{"a":".right_banner_hold"},{"a":"section[id^=\"ctup_ads-\"]"},{"a":".article-partners"},{"a":".holiday-banner-bl,\n.trn-info-block"},{"a":"#archive-video-player,\n.bookmaker"},{"a":".col__big .unit-rubric__head[style^=\"margin-top:\"],\n.footer-partners,\n.partner-news-content,\n.sponsors-holder"},{"a":"#left_news_list_article,\n#modal_window,\n#overlay_fb_modal,\n#right_300x600,\n.article-informer"},{"a":"#above-header,\n.ai-placement,\n.block-custom-banners,\n.new-banners,\n.znaj-banners_ajax,\na[href^=\"http://prive.kiev.ua\"],\ndiv[class*=\"advertising\"]"},{"a":".sidebar > .widget_rvuoi:nth-child(-1n+4)"},{"a":".posts-list-banner"},{"a":"#text-10,\na[href^=\"http://robotsforex.ru/sale/\"],\na[href^=\"https://my.alfa-forex.ru/ru/registration/\"]"},{"a":".bVerticalRectangle,\n.middleboard,\n.rightContainer > .floating_banner,\niframe[src*=\"/www/delivery/\"]"},{"a":"[class^=\"reklama-ads-\"]"},{"a":"#oframeplayer > [class][style^=\"display: block\"],\n.block-info-vertical"},{"a":"div[class*=\"adv-\"]"},{"a":"#offerPopup"},{"a":".post__banner,\nvideo[src*=\"/storage/uploads/\"][src$=\".mp4\"]"},{"a":".header-reklama"},{"a":".LeaderBoard,\n.contentBoxR.floating_banner"},{"a":"#middle_section > div[style^=\"float:\"],\n#right_section > div[style^=\"height: 400px\"],\n#top_two_article"},{"a":".sidebar > .adv ~ *"},{"a":"[onclick*=\"ClickOnAd\"],\n[onclick*=\"ClickOnBanner\"]"},{"a":"#ovva-player .o-pp,\n.google_970x90 > div:empty,\n.online-container > div[class$=\"-background\"]:empty,\n.online-container a[class*=\"space-link\"],\n.online-sport-top-banner-bg,\n.sidebar-banner > div:empty,\n.video-container > div[class$=\"-background\"]:empty,\n.video-container a[class*=\"space-link\"],\na[href*=\"://h.holder.com.ua/c?tz\"],\ndiv[class$=\"_ad\"] > div:empty"},{"a":".under-player"},{"a":".nav > ul > li > [title=\"Досуг\"],\n.nav > ul > li > [title=\"Знакомства\"]"},{"a":"#bnadplayer,\n.fullpanefn"},{"a":"body > div > .a-overlay"},{"a":".body-sub-form"},{"a":".detected-block-modal,\n.js-detected-block"},{"a":"a[href$=\".php\"] > img,\na[href*=\".htm\"] > img"},{"a":"#top-page-ads,\n.ablock_side,\n.header2,\n.main_top_ads"},{"a":".darkrek"},{"a":"a[href][target=\"_blank\"][style^=\"display:\"],\ntd[width=\"200\"][valign=\"top\"] > a[href]"},{"a":"body > div > .container > a[href][target=\"_blank\"]"},{"a":"#register_popup"},{"a":".makeBet,\n.zoneBanner"},{"a":"body > div:not([id]):not([class]) + div:not([id]):not([class]) + div:not([id]):not([class]) + div:not([id]):not([class]) ~ div[id]:not([class])"},{"a":"a[rel=\"nofollow\"][target=\"_blank\"][href^=\"http://lu4ok.ws/go/?\"]"},{"a":".plaintext > noindex,\nnoindex > .lastnews"},{"a":"iframe[src*=\"gnezdo.ru\"]"},{"a":"#page > noindex a[href][target=\"_blank\"]:not([href^=\"http://praetorians.ws/forum/\"])"},{"a":".soft-day:not(:first-child) > .box,\ncenter > .box-shadow + table:last-child"},{"a":".topad_banner"},{"a":"#dle-content > table[width=\"100%\"][height],\n#torrent_77_info,\n.separator,\ntd.topBorder > table[width=\"100%\"][height]"},{"a":"#begin #userlinks"},{"a":"#n-Группа-в-Дискорде,\n#n-Канал-в-Телеграме,\n.sitenotice > .floatleft + p + p,\n.sitenotice > hr ~ div"},{"a":"div[style^=\"background:\"][style*=\"/ple.jpg)\"]"},{"a":"a[href^=\"http://iq-option.org/\"]"},{"a":"iframe[src*=\"/banner/\"]"},{"a":"div[id^=\"post\"] > .tech-info + :empty"},{"a":"img[src][width=\"241\"][height=\"383\"],\nimg[src][width=\"300\"][height=\"216\"]"},{"a":"#sidebar > .theiaStickySidebar > .widget_media_image"},{"a":".b-flex,\n.l-a-fly"},{"a":".adv-links"},{"a":"div[class^=\"adace\"]"},{"a":".main > a[href*=\"bit.ly\"] > img,\np.main:has([href*=\"bit.ly\"])"},{"a":"#gkadblock"},{"a":".banner__holder"}];

const hostnamesMap = new Map([["bug.org.ua",0],["buhoblik.org.ua",1],["cfts.org.ua",2],["old.cfts.org.ua",3],["dialogs.org.ua",4],["e-bookua.org.ua",5],["hitline.org.ua",6],["mv.org.ua",7],["patrioty.org.ua",8],["reaction.org.ua",9],["risu.org.ua",10],["tenews.org.ua",11],["teremok.org.ua",12],["testkrok.org.ua",13],["umu.org.ua",14],["osvita.ua",15],["petcare.ua",16],["ng.pl.ua",17],["pogliad.ua",18],["setup.pp.ua",19],["pravdatut.ua",20],["price.ua",21],["profootball.ua",22],["protocol.ua",23],["radioroks.ua",24],["rau.ua",25],["rbc.ua",26],["recept.ua",27],["reono.ua",28],["reporter.ua",29],["rst.ua",30],["my.rv.ua",31],["rivnepost.rv.ua",32],["torg.rv.ua",33],["vse.rv.ua",34],["sd.ua",35],["segodnya.ua",[36,37]],["u24.ua",[36,64]],["game.segodnya.ua",[38,39]],["sport.segodnya.ua",[38,40]],["senior.ua",41],["sinoptik.ua",42],["slovoidilo.ua",43],["smartphone.ua",44],["sport.ua",[45,46]],["sportonline.ua",46],["dobre.stb.ua",47],["strahnadzor.ua",48],["stroyobzor.ua",49],["subbota.ua",50],["forums.sumy.ua",51],["tabletki.ua",52],["te.ua",53],["doba.te.ua",54],["nday.te.ua",55],["poglyad.te.ua",56],["telekritika.ua",57],["teleportal.ua",58],["traktorist.ua",59],["tsn.ua",60],["market.tut.ua",61],["tvi.ua",62],["tyzhden.ua",63],["ubr.ua",65],["upl.ua",66],["uteka.ua",67],["val.ua",68],["vesti.ua",69],["vgorode.ua",70],["vikka.ua",71],["viva.ua",72],["work.ua",73],["xsport.ua",74],["zi.ua",75],["zn.ua",76],["znaj.ua",77],["golos.zp.ua",78],["inform.zp.ua",79],["medved.us",80],["gazeta.uz",81],["kinohit.uz",82],["mover.uz",83],["nuz.uz",84],["podrobno.uz",85],["repost.uz",86],["sports.uz",87],["spot.uz",88],["stadion.uz",89],["vesti.uz",90],["yellowpages.uz",91],["1plus1.video",92],["kinoprofi.vip",93],["homeporn.website",94],["serial.wiki",95],["torrnado.win",96],["gdz-ru.work",97],["ppc.world",98],["2baksa.ws",99],["cont.ws",100],["darkwebs.ws",101],["filebase.ws",102],["igraprestolov.ws",103],["kote.ws",104],["lfootball.ws",105],["livesport.ws",106],["lu4ok.ws",107],["oane.ws",108],["onlyf.ws",109],["praetorians.ws",110],["samlab.ws",111],["forum.smolensk.ws",112],["xtreme.ws",113],["zarulem.ws",114],["lurkmore.wtf",115],["xn--c1ajfnfb.xn--p1acf",116],["xn----dtbfdbwspgnceulm.xn--p1ai",117],["xn----etbbecbrbp5ahkja1ae7v.xn--p1ai",118],["xn---2--mddxunv8a2esa.xn--p1ai",119],["xn--24-7lcajlu.xn--p1ai",120],["xn--80acvefn6a4c.xn--p1ai",121],["xn--80ady2a0c.xn--p1ai",122],["xn--c1acj.xn--p1ai",123],["xn--k1afadd0cwc.xn--p1ai",124],["cameleo.xyz",125],["gk-stalker.xyz",126],["xporno.xyz",127]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
