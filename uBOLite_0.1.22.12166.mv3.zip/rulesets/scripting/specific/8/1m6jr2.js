/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// jpn-1

const argsList = [{"a":"#oCntrAd,\n#spgLoadAd,\n.apiRsltAd,\n.apiRsltFigAd"},{"a":".ado-area"},{"a":".onk16-widget,\ndiv[id^=\"onk16\"][style=\"width: 300px; \"]"},{"a":".aban"},{"a":"div[style$=\"min-height:175px;\"]"},{"a":"[id^=\"dmm_\"]"},{"a":".goods"},{"a":"#amazon-article,\n#tag-related + div.headline1,\ndiv[class^=\"ad_side_widget\"]"},{"a":"#wrapper > div[style=\"text-align:center;padding-bottom:15px;\"]"},{"a":".oumi-widget"},{"a":".kijinai_ad"},{"a":".maintop-widget,\n.singletop-widget,\n.widget_text.mainbottom-widget"},{"a":".sub-content > div[style=\"width:200px; height:200px;\"]"},{"a":"td[width=\"131\"]"},{"a":"a[href^=\"http://www.e-nls.com/access.php\"]"},{"a":".actions + section[style^=\"text-align: center; background: #FFF\"],\n.d_header"},{"a":".adMiddleRect2Css"},{"a":".pr_box"},{"a":"#commentbody > div[style^=\"margin:5px 0px\"],\n.basehtml_side,\n.blogparts_freeArea:last-child,\n.inner_footer,\n.kiji_chuubu,\ndiv.mainmore > .inner"},{"a":"#links-left > section.-freeArea:last-child,\n.Article__content > div[align=\"center\"] > br"},{"a":".sponsor-responsive,\ndiv[id$=\"-rectangle\"],\ndiv[id^=\"ad-\"]"},{"a":"a[href=\"/adcookie.php\"],\np.“hidden-print”"},{"a":".billboard__pr"},{"a":"#bottom_overlay_area,\ndiv[class^=\"ADD\"]"},{"a":"div[style*=\"height:250px;\"]"},{"a":"#maintitle_ad"},{"a":".entry-content > div[style=\"margin:0;padding:5px;font-size:14px;word-break: break-all;\"]"},{"a":".item[style],\ndiv[style^=\"width:1290px; height:280px\"]"},{"a":"td[rowspan=\"4\"][valign=\"top\"][nowrap=\"\"][align=\"left\"]"},{"a":"#text-50,\ndiv[class^=\"gads-space\"]"},{"a":".news-list-ad"},{"a":".plugin-message,\n.t_b[style^=\"font-weight:bold;font-size:16px;line-height:24px;background-color:#f5f5f5\"]"},{"a":"#links"},{"a":".text > a[href^=\"https://amzn.\"],\nimg[src*=\"amazon-adsystem\"] + br + a"},{"a":"#ads_fieldOuter,\n#g_floating_tag_zone,\n#recommend_ad,\ndd + table[cellspacing=\"0\"][cellpadding=\"0\"][border=\"0\"],\ndiv[style^=\"width:300px; height:250px\"]"},{"a":"#bnr1,\n#bnrSuperbannerBottom,\n#pc-campaign-appeal-01,\n#premiumPanel"},{"a":"a[href^=\"https://www.e-nls.com/access.php\"],\ncenter > table[width=\"935\"][height=\"100\"][cellpadding=\"10\"][bgcolor=\"peru\"],\nspan[style=\"display:block;margin:5px 0 0 0;padding:0;text-align:center;\"]"},{"a":"table[style=\" FONT-SIZE: 18px\"][bgcolor=\"#ffffff\"][width=\"800\"][height=\"400\"],\ntable[style=\"FONT-SIZE: 12px\"][bordercolor=\"#ffccff\"][width=\"800\"][height=\"220\"],\ntd[valign=\"middle\"][width=\"800\"] > strong:first-child > font[color=\"#ff0000\"]:only-child"},{"a":".ds.first"},{"a":"#sub div.column-inner-2 > br,\n#sub div.column-inner-2 > table[border=\"0\"]"},{"a":".wp-block-wp-quads-adds,\namp-iframe"},{"a":"#right_folder > div.textwidget > a[rel^=\"nofollow\"] > img"},{"a":".banner3"},{"a":"#text-67,\n.stickyunit"},{"a":"#popup_area,\n.p-side-banner-lists"},{"a":"#amgatti_sk-3,\n#pc_text-80"},{"a":".widget_text.ad"},{"a":"#down-articles > div.textwidget,\n#mybox > div.textwidget:first-child"},{"a":"td[style=\"background-color: #ffffff; text-align: center; border: 1px solid #ffffff; height: 65px;\"][colspan=\"3\"]"},{"a":"p[style*=\"color:#333; text-align:center;\"]"},{"a":"br + center:last-child"},{"a":"#pc_all_inarticle,\n#pc_right_1st,\n#pc_right_2nd,\n.header-bn"},{"a":"a[data-atag-id]"},{"a":".junk-ad-body,\n.nva-center"},{"a":"#side-fix,\ndiv[style$=\"height:280px;\"]"},{"a":"#adexchange,\n.ad-bnr,\n.banners,\n.related,\nul > li.block-pr"},{"a":"a[href^=\"https://click.linksynergy.com/fs-bin/click\"],\na[href^=\"https://contents.fc2.com/aff.php\"]"},{"a":"div[class^=\"bg_ad_\"]"},{"a":"#is_w_area,\n.__isboostReturnAd"},{"a":".adDown"},{"a":".amazon.Default"},{"a":"#widget-under-sns-buttons"},{"a":".extendedwopts-show,\ndiv[style^=\"width:336px;height:280px\"]"},{"a":".single-gallery-ad-hol-block,\n.webcg-1030,\n.webcg-ad1,\ndiv[id^=\"sub-top_2nd\"]"},{"a":".entry-content > table[style=\"border-style: none;\"][border=\"1\"]"},{"a":"#media_image-10,\na[href^=\"https://www.banggood.com/\"],\ndiv[style=\"padding:20px 0px;\"] > center"},{"a":".ads-native"},{"a":".contentes_banner_2,\n.contents_ads_relation,\n.top_bottom_banner_box"},{"a":".monthly_popular_wrap,\n.top_rss_side_ad"},{"a":"#third > div.plugin-memo:first-child,\n.adad"},{"a":".hentry > .kizi-under-box:first-child"},{"a":".hentry div[style=\"text-align:center;\"]"},{"a":".topAdsenseArea"},{"a":".banner-yoko"},{"a":"#navi_recommend,\ndiv[id$=\"_ads\"]"},{"a":"#body > table:last-child"},{"a":"#secondary > div.widget_execphp,\n#text-34,\n.free-area_after-cont > div.widget_custom_html,\n.free-area_before-title > div.widget_execphp"},{"a":".MenuBox[style=\"padding: 5px; min-height: 280px;\"]"},{"a":".ad[style^=\"min-width: 300px; min-height: 250px\"],\n.ad[style^=\"width:300px; height:250px\"],\n.ad[style^=\"width:310px; height:250px\"],\ndiv[id][style=\"width:300px;height:600px;\"],\ndiv[style^=\"min-width: 640px\"],\ndiv[style^=\"width:600px; height:200px\"]"},{"a":".conteiner__main > div[style=\"line-height:1; border-bottom:1px solid #ccc; padding:8px;\"],\n.conteiner__main > div[style=\"min-width:686px;min-height:557px;\"],\n.page_hedding,\ndiv[style^=\"min-width:300px;min-height:250px\"]"},{"a":"#secondary > div.embed-responsive,\n#secondary > div.small,\n#secondary > video.w-100"},{"a":"#bigup2,\n#fuji-fns,\n#wrap_banner_billboard,\n.pr_contents,\n[class*=\"banner_type_\"],\nbody > div#curtain + div.container[id],\ndiv[style^=\"border:1px solid #CCC;width:300px;margin:\"]"},{"a":".wrap_pr_300_sky"},{"a":".fixed-bottom,\ndiv[class^=\"my-ad\"]"},{"a":"div[id^=\"im-\"][style=\"min-height: 90px; margin-bottom: 1rem;\"],\ndiv[style$=\"min-height:250px;\"]"},{"a":".ad_3rec,\n.container_top_widget"},{"a":".widget > a[href][target=\"_blank\"] > img"},{"a":".gad_pc"},{"a":".sidebar > section[id^=\"custom_html-\"],\nbody .my_adslotd"},{"a":"#ad-double-rectangle"},{"a":"#ad_rudel_1,\n#ad_rudel_2,\n#advertisement_amazon,\n#maniax,\n#okazu_resemble_games,\n#recent_recommendations,\n#this_week_release"},{"a":"#ad-box3"},{"a":".b-r--before-site-content,\ndiv[style=\"min-height: 280px;\"]"},{"a":".author + div.archive,\n.single > p[style=\"margin-bottom:10px;\"]"},{"a":"div[style=\"text-align:center;background-color:#000000;color:#FFFFFF\"],\ndiv[style=\"width:160px;margin-right:-175px;float:left;\"] > div[style=\"margin-top:10px;text-align:center;\"]:last-of-type,\ndiv[style=\"width:466px;background:#000000;color:#FFFFFF;text-align:center\"]"},{"a":"#p-SponsoredLink,\ndiv[style=\"font-size: 11px;\"]"},{"a":"body > div[style=\"text-align: center;\"]"},{"a":".adspc,\n[class^=\"sponsor\"]"},{"a":".nearby > li:last-child:not([class])"},{"a":".ads_pc_rectangle"},{"a":".article__content > h3.module__heading,\n.module--category-recent-entry,\n.rss-unit,\n.side--right > section.module--free,\n[class*=\"spad_\"]"},{"a":"div[id^=\"1\"][style*=\"height\"][style*=\"width\"],\ndiv[style^=\"margin:0 auto;height:\"][style$=\"px;\"]"},{"a":"div[class^=\"adsense_article_\"]"},{"a":".side_category + aside"},{"a":".left_main > a,\n.sample_block"},{"a":"#text-26,\ndiv[id^=\"omc_ad_widget\"]"},{"a":"#myinvidad,\n#thbss > div > a[onclick][title=\"CLOSE\"]"},{"a":"div[style=\"text-align:center\"]"},{"a":"#popup-container"},{"a":".bottompr,\n.toppr,\n.videobottompr320x100"},{"a":".l-sidebar > aside.widget_block"},{"a":"span#ad"},{"a":".normal-sidebar a[href^=\"https://www.amazon.co.jp/gp/\"]"},{"a":".sidebar2.sidebar.col-sm-3,\n.widget_sponsored_area"},{"a":"#ad_html,\n#new_ad_html"},{"a":"#headerafficode"},{"a":"#preview_dispAffi"},{"a":"#col3,\n#execphp-4"},{"a":"p > a[target=\"_blank\"] > img"},{"a":"#ufw_1"},{"a":".ads_za"},{"a":"#player-container,\n.a-d-block,\n.set_height_250,\ndiv[id][style^=\"position: absolute;  z-index: 12345;width: 100%; height: 100%; left: 0;  top: 0;background: gold;\"]"},{"a":".aasc.center > iframe[class*=\"lazyload\"],\n.sidebar > [class]:first-child,\n[style=\"text-align:center;height:280px;overflow:visible!important;\"],\ndiv[style*=\"min-height\"]:not([class]),\ndiv[style=\"width:100%;max-width:730px;height:auto;min-height:190px;\"]"},{"a":"#container > div[style=\"margin:0 auto;margin-top:2px;min-height:95px;text-align:center;\"],\n#sub > div.column-inner > div.column-inner-2 > div[style=\"text-align:center;\"],\n#sub a[href^=\"https://www.amazon.co.jp/gp/\"],\n.article-outer-3 > #article-options,\ndiv[style=\"width:100%;height:300px;\"]"},{"a":"#prs"},{"a":".p-table__contents--full.u-pt30vw-down-md"},{"a":".u-dib"},{"a":"#bottomNbox,\n.wide_adbox"},{"a":".ad-banner:not([data-name=\"single-related-posts\"])"},{"a":".post > .section-in > div[align=\"center\"],\n.post > .section-in > table"},{"a":"div[id^=\"gpt-ad\"]"},{"a":"div[class^=\"fluct-unit\"]"},{"a":".pr_link"},{"a":"div[style=\"width: 970px; margin: 0 auto 30px;\"]"},{"a":".ad-common_pc-ranking"},{"a":"iframe.yahoo"},{"a":".my-adspace"},{"a":".row > div[class^=\"col-md-\"] > div[style^=\"text-align:center;margin-bottom:\"] > table[border=\"0\"]"},{"a":".bnr_wd_wrap"},{"a":"div[class^=\"gptad\"]"},{"a":".footer-ads-recipe"},{"a":"#dmm_comic_latest"},{"a":"#txtPr > span"},{"a":".home-featured-ad,\n.poplayer"},{"a":".adcopy2 > a"},{"a":"div[style^=\"max-width: 1000px; width: 90%; height: 400px;\"]"},{"a":".lala-common-ad"},{"a":"div[class^=\"style_ad\"],\ndiv[class^=\"style_under_toc_ads\"]"},{"a":"#top-ad1-wrapper,\ndiv[id^=\"broadcast-content-ad\"],\nsection[id^=\"common-content-top-ad\"],\nsection[id^=\"top-sidebar-ad\"]"},{"a":".adframe-container"},{"a":".video-plugin-skip-button"},{"a":"div[class=\"col-sm-12\"] > font[color]"},{"a":".brand_panel"},{"a":"div[style^=\"text-align:center;width:336px\"]"},{"a":"#the-content > hr:last-of-type,\n#the-content > p > a[href^=\"https://hb.afl.rakuten.co.jp/\"],\n#the-content > p > a[href^=\"https://px.a8.net/svt/ejp?\"]"},{"a":"div[style=\"width:100%;background-color:#000;\"]"},{"a":"#product"},{"a":".ggle-ad"},{"a":"#sidebar > p.mg_b_5[style],\ndiv[style=\"width: 300px !important; height: 250px !important;margin-bottom:20px;\"],\np[style=\"margin-top: 80px;\"]"},{"a":".tes_wrap"},{"a":".c307ad"},{"a":".modal_mo"},{"a":".entry-content > p > a[href^=\"https://al.dmm.co.jp/\"],\n.entry-content > p > a[href^=\"https://happymail.co.jp\"],\n.entry-content > p > a[href^=\"https://wlink.golden-gateway.com\"]"},{"a":".sideBlock:first-child"},{"a":"#text-html-widget-2,\n.dspace-block,\n.wpap-tpl,\ndiv[style*=\"min-height\"][style*=\"height: auto\"]"}];

const hostnamesMap = new Map([["o-dan.net",0],["okazurand.net",1],["blog.onk164.net",2],["openworldnews.net",3],["orefolder.net",4],["sp.oshaburi.net",5],["oshiete-kun.net",6],["otakuma.net",7],["otoriyose.net",8],["ouminews.net",9],["oursounds.net",10],["pazudora-news.net",11],["pictbland.net",12],["pig109.net",13],["pinknotora.net",14],["dic.pixiv.net",15],["plicy.net",16],["pokema.net",17],["pokemon-matome.net",18],["pokemongo-kouryakumatome.net",19],["print-kids.net",20],["privatter.net",21],["rakuten-sec.net",22],["rankingoo.net",23],["relazo.net",24],["rocomotion.net",25],["roshutu-shuuti.net",26],["rubese.net",27],["sagaoz.net",28],["sbapp.net",29],["news.searchina.net",30],["helloprojects.seesaa.net",31],["my0nio.seesaa.net",[32,33]],["oto-suu.seesaa.net",32],["jbbs.shitaraba.net",34],["shufoo.net",35],["i-bbs.sijex.net",36],["silky-love.net",37],["sk2ch.net",38],["ske48matome.net",39],["smatu.net",40],["solomon-review.net",41],["spoen.net",42],["sqool.net",43],["studyhacker.net",44],["sumahoinfo.net",45],["sundaygamer.net",46],["takamaru1219.net",47],["english.talk-sense.net",48],["talknews.net",49],["taruo.net",50],["news.tennis365.net",51],["toaru-web.net",52],["tokyomotion.net",53],["toushichannel.net",54],["toyokeizai.net",55],["travel-nippon.net",56],["tvjapan.net",57],["twivideo.net",58],["twtimez.net",59],["valorantchannel.net",60],["vip-jikkyo.net",61],["warotanien.net",62],["webcg.net",63],["wikinis.net",64],["win-tab.net",65],["with2.net",66],["wood-museum.net",67],["world-fusigi.net",68],["worldfn.net",69],["xn--cbkxbyfwj.net",70],["xn--o9jx06gxedxziu2np5bluqts8d30r.net",71],["yoheim.net",72],["youravhost.net",73],["yugalab.net",74],["yugioh-wiki.net",75],["zekamashi.net",76],["zyuken.net",77],["hochi.news",78],["kahoku.news",79],["kumin.news",80],["gigafile.nu",81],["choosar.gigafile.nu",82],["shortener.gigafile.nu",83],["wiki.yjsnpi.nu",84],["dougle.one",85],["rallys.online",86],["live-events.a-jp.org",87],["androplus.org",88],["chomanga.org",89],["erogamescape.dyndns.org",90],["favolog.org",91],["ieeebd.org",92],["johndoeblog.org",93],["kabegami.jpn.org",94],["kaworu.jpn.org",95],["nekonikoban.org",96],["news-us.org",97],["postmap.org",98],["refind2ch.org",99],["bnewg.sokuho.org",100],["syosetu.org",101],["hinode.pics",102],["bokunokanojo.pink",103],["sexywars.pink",104],["eigo.plus",105],["cndata.jpg4.pw",106],["dateplus.red",107],["shop-flashka.ru",108],["stanok-chel.ru",109],["hedgehog.ryukyu",110],["maguro.2ch.sc",111],["geek.sc",112],["share-videos.se",113],["embed.share-videos.se",114],["animemaruwakari.site",115],["bokumato.site",116],["ero-mag.site",117],["phuot.site",118],["vimv.site",119],["zabuu.site",120],["7mmtv.sx",121],["coron.tech",122],["connect.coron.tech",123],["jump.x0.to",124],["mag.digle.tokyo",125],["movie.digle.tokyo",126],["game-news.tokyo",127],["hanako.tokyo",128],["l-media.tokyo",129],["web.playerapp.tokyo",130],["urbanlife.tokyo",131],["rakko.tools",132],["corriente.top",133],["reminder.top",134],["times.abema.tv",135],["best-hit.tv",136],["i.best-hit.tv",137],["cazual.tv",138],["cchan.tv",139],["delishkitchen.tv",140],["erovideon.tv",141],["hamazo.tv",142],["hpav.tv",143],["ikora.tv",144],["javmix.tv",145],["lala.tv",146],["mamadays.tv",147],["ohen.tv",148],["wav.tv",149],["jpshowbiz.us",150],["2ch.vet",151],["abstractpainting.work",152],["efootball.work",153],["glossary.work",154],["rorriiianime.work",155],["tkgstrator.work",156],["4thsight.xyz",157],["k3su.xyz",158],["shico.xyz",159],["theav.xyz",160],["wazaari.xyz",161],["xn--8uqt3cty5bwwbwwh.xyz",162],["hamakore.yokohama",163],["socom.yokohama",164]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
