/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// spa-1

const argsList = [{"a":"#mrec"},{"a":"#frase2"},{"a":".banner-obj"},{"a":"div[class^=\"t-pub-box-\"]"},{"a":"a[href^=\"http://ad.doubleclick.net/\"]"},{"a":".wow-modal-overlay"},{"a":".beachPartners,\n.dealer-block,\n.liveCamInfoContainer > div.sponsorContainer + div"},{"a":"#table50"},{"a":".commBanners"},{"a":".ad-slot,\n.rmp-ad-outstream,\n.stack__ads,\na[href^=\"http://bs.serving-sys.com/\"]"},{"a":"[align=\"right\"][width=\"348\"],\n[height=\"76\"][width=\"8\"]"},{"a":".GooglePub300_250,\n.PubGoogle300"},{"a":"#MREC2,\n#pub728x90ifrm,\n.BoxPub300x250,\n.PagInicialPub2,\n.bannerMrec,\n.comentariosPag,\n.cx-iniciativas-pub,\n.special-ctn,\n[style=\"WIDTH:300px; margin-bottom:10px; TEXT-ALIGN:right\"],\n[style=\"padding: 20px 0px; text-align: center; height: 90px;\"],\n[style=\"padding:20px 0px; text-align:center; height:90px\"],\n[style=\"width: 300px; margin-bottom: 10px; text-align: right;\"],\n[style=\"width: 527px; height: 150px; float: right;\"],\n[style=\"width:527px; height:150px; float:right\"],\ntable[cellpadding=\"5\"][width=\"641\"]"},{"a":".pubTextInfo,\ndiv[id^=\"pubText_\"]"},{"a":".odigi-adlabel"},{"a":"div[id^=\"ws_widget__ad_\"]"},{"a":"#TinAdPopup"},{"a":".t-a-pub-1,\n.t-pubbox-bb-1,\n.t-pubbox-mrec-1"},{"a":"#magazine_modules_receivenewsletter,\n.stk_666"},{"a":".pubframe"},{"a":"#adslot-side-mrec,\n#adslot-top-lead"},{"a":".theiaStickySidebar > #custom_html-2"},{"a":"#ba_avanza,\n#ba_interbanco"},{"a":".adp,\n.adp-underlay"},{"a":".adsInfo,\n.adsLateral"},{"a":"body ~ iframe[style*=\"width:\"][style*=\"opacity:\"][style*=\"z-index:\"][style*=\"position:\"]:not([src])"},{"a":"div[class*=\"gg_ads\"]"},{"a":".enlace_descarga"},{"a":".entry-content center > a[rel=\"noopener\"] > img"},{"a":"#sticky-banner1"},{"a":".inside-header > a[target=\"blank\"] > img,\n.inside-right-sidebar > #custom_html-4"},{"a":".happy-player-beside,\n.player__happy-inside"},{"a":"a[class^=\"reserve-button\"][target=\"_blank\"] > img,\ncenter > a[class^=\"super-r-button\"] > img"},{"a":".happy-section,\ndiv[class^=\"adde_\"],\ndiv[id^=\"adde_modal-\"]"},{"a":"#content > .contentBox + center,\n#sidebarGeral > .sidebar:first-child,\nbody > center"},{"a":".DvrAbs"},{"a":"#firstClick"},{"a":".the-banner"},{"a":"center > a[target*=\"_blank\"] > img"},{"a":"#frutuante"},{"a":"td[width=\"961\"][height=\"60\"]"},{"a":"#iphone_banner"},{"a":".Ads"},{"a":"td[class=\"style6\"][style=\"height: 53px\"]"},{"a":".generalModal"},{"a":"a[href^=\"https://btt-pt.toldmeroc.com/\"]"},{"a":".TPlayerNv > .Button.STPb[data-tplayernv=\"Opt0\"],\na[href^=\"https://ocio.leadzutw.com/\"]"},{"a":"a[href^=\"http://www.portablemusic.mobi/\"],\np > a[href][rel=\"noopener\"][target=\"_blank\"] > img"},{"a":"#cointainerBanner300,\ndiv#banner300x250"},{"a":".ParceirosLink,\n.Publicidade728"},{"a":"iframe[width=\"220\"]"},{"a":"#superderbi"},{"a":"#capa2"},{"a":"a[href^=\"/play/\"]"},{"a":"body > .vizerNewBox.adsByVizer"},{"a":".comments-pub,\n.movies-pub"},{"a":"a[href^=\"http://www.neobux.com/\"]"},{"a":".ads-container,\n.ads-under-header,\n.editorial-ads,\ndiv[style=\"width:300px;padding:4px;margin:8px;float:left;border:0px solid #eeeeee;\"]"},{"a":".module1colAds,\ndiv[class*=\"category-secondary-ad\"]"},{"a":".ultim-adlabel + a[rel=\"nofollow\"],\ndiv[class^=\"ultim-\"]"},{"a":"a[href^=\"https://bit.ly/\"] > img"},{"a":"#adxx"},{"a":".adorshop,\ndiv[style=\"margin-top:.5em;min-height:312px\"]"},{"a":"td[height=\"630\"]"},{"a":"#adsacumulada,\n#adsalosexo,\n#adscamerasex,\n#adsempire,\n#adsmp,\n#adsoriginal,\n#adspb,\n#amigos"},{"a":".sidebar section.widget_block > a[target=\"_blank\"] > img"},{"a":".fg1 > a[target=\"_blank\"].snd"},{"a":"#videoss > section:not([class]),\n.dvcss"},{"a":"#text-19,\n.top-header-ads-mobile"},{"a":".mt_ad"},{"a":"div[class$=\"-iframe mb-20 text-center\"]"},{"a":".ad-bodyvideo"},{"a":".lst_ft_bn"},{"a":"#block-7,\n.rteam_antiadb"},{"a":"div[style^=\"width:300px;height:250px;display: inline-block;\"]"},{"a":"div[style][onclick*=\"anunciotag()\"]"},{"a":"#custom_html-2"}];

const hostnamesMap = new Map([["iol.pt",0],["rr.pt",0],["sapo.pt",[0,12]],["diario.iol.pt",1],["ionline.pt",2],["jn.pt",3],["jornaldenegocios.pt",4],["jornaleconomico.pt",5],["beachcam.meo.pt",6],["miau.pt",7],["millenniumbcp.pt",8],["publico.pt",9],["record.pt",10],["rtp.pt",11],["kbb.sapo.pt",13],["odigital.sapo.pt",14],["pplware.sapo.pt",15],["visao.sapo.pt",16],["tsf.pt",17],["xl.pt",18],["zerozero.pt",19],["forum.zwame.pt",20],["portal.zwame.pt",21],["lanacion.com.py",22],["link-descarga.site",23],["superanimes.site",24],["pelisplus.so",25],["pdfslide.tips",26],["1v.to",27],["comando.to",28],["canaistv.top",29],["downloadcursos.top",30],["hentai-asia.top",31],["mrpiracy.top",32],["porno-japones.top",33],["animesorion.tv",34],["animespace.tv",35],["cablegratis.tv",36],["canalnet.tv",37],["comandotorrent.tv",38],["filmeshd.tv",39],["infonegocios.tv",40],["justin.tv",41],["lasestrellas.tv",42],["calcular.onlinegratis.tv",43],["pobre.tv",[44,45]],["pobre.wtf",44],["seriesgato.tv",46],["televisionparatodos.tv",47],["tu.tv",48],["tudotv.tv",49],["tuporno.tv",50],["verfutebol.tv",51],["vertelevision.tv",52],["vidcorn.tv",53],["vizer.tv",54],["wareztuga.tv",55],["tvperuana.us",56],["elpais.com.uy",[57,58]],["ovaciondigital.com.uy",58],["ultimasnoticias.com.ve",59],["tabonitobrasil.video",60],["repelisplus.vip",61],["numero.wiki",62],["juegosypelis.ws",63],["revistasgratis.ws",64],["cuevana-3.wtf",65],["pelispedia-v2.wtf",66],["aztecapornohd.xxx",67],["hentaiporno.xxx",68],["morritastube.xxx",69],["pornburst.xxx",70],["pornolandia.xxx",71],["tupornogratis.xxx",72],["animesonehd.xyz",73],["clickhouse.xyz",74],["playnewserie.xyz",75],["suasaudeonline.xyz",76]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
