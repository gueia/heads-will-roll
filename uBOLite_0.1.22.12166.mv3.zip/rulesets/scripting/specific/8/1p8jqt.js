/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// idn-0

const argsList = [{"a":"[href=\"http://click2go.me/aksesklik4a\"]"},{"a":"#teaser5"},{"a":"[class^=\"sgpb-\"]"},{"a":"#previewBox3"},{"a":"#flobwh,\na[href^=\"https://rebrand.ly/\"]"},{"a":"#floatbot,\n.appup"},{"a":".nyaa300,\n.nyaa728"},{"a":".adsbygoogle"},{"a":".sidebar > .klan300"},{"a":".bausastra-ads"},{"a":".affcoups"},{"a":".inf_infusionsoft_popup"},{"a":"div.ui_adblock"},{"a":"#TopBannerBg"},{"a":".bnr"},{"a":".banner-sc,\n.banner-sc2,\n.col-banner,\n.masonry-brick.drm-banner-x.drm-artikel:nth-of-type(3)"},{"a":".header__kasad,\n.kasad-h"},{"a":"#adsoutsream,\n.heightads250"},{"a":"#fixslowshow"},{"a":"#dablewidget_RoOGdzom,\n#div-Skycrapper-Stocksetup,\n.heightads600.pad-t.pad-r.pad-l.pad-10,\n.heightads90.ads-middle-list-news,\n.text-center.center.width-px-1100"},{"a":"#Kolom-random-300,\n#iklan-dalam-postingan-300,\n#overlay[style=\"display: block;\"],\nimg[style=\"border:0;display:block;\"]"},{"a":"#top-banner-parallax,\n.banner-parallax"},{"a":".adsense"},{"a":".ads-160,\n.ads-160-600,\n.ads-300-video,\n.set-ads-468,\na[style=\"width: 100%; height: 100%; display: block; position: fixed; z-index: 1\"]"},{"a":"#otp_ads,\n.portlet.sideskycrapper"},{"a":"#bottomframe-ad,\n#skinframe-ad-left"},{"a":".ad-inventory-wrapper"},{"a":"a[href^=\"http://www.apktiga.com/p/start-download-reayus.html\"]"},{"a":"#detailSkinAdLeft,\n#detailSkinAdRight"},{"a":".ads-mr,\n.ads__skyscraper,\n.ads_sky"},{"a":".mt20.top1,\ndiv.banner-r"},{"a":"#div-top-banner-transparent"},{"a":".ads_sticky_footer"},{"a":".ads-sticky-left,\n.ads-sticky-right,\n.bg-grey.text-center.p-0.mb-3.mt-3,\n.mb-4.bg-grey.text-center"},{"a":".ad-box-wrappr,\n.row > .show-desktop > div,\n.underlay-ad-text-box"},{"a":".nkt__stick"},{"a":"#main-banner-middle,\n.legend_banner-container,\n.stickybanner"},{"a":".ftadss"},{"a":".parallax_ads,\n.widebanner.banner,\ndiv.showcase.banner,\ndiv.skycrapper.banner"},{"a":".cls.code-block-center"},{"a":".banner-skin--left,\n.banner-skin--right,\n.banner__giant.banner,\n.banner__left.banner,\n.banner__right.banner,\n.banner__top.banner"},{"a":".ads-popup__inner"},{"a":".ads.single_post_content,\n.animated.ads"},{"a":".adbox"},{"a":".skinner-left,\n.skinner-right"},{"a":".box-ads-300x250"},{"a":".text-align-center.box-ads-content"},{"a":".in_up_ad-area"},{"a":".cads"},{"a":"#ilang2"},{"a":".modal"},{"a":".box-banner"},{"a":"#floating_ads_bottom_textcss2"},{"a":".wait"},{"a":"[href=\"javascript:showHideGB()\"],\n[href^=\"http://dwatngkas.\"],\na[href^=\"http://cocobet.\"]"},{"a":"#ilang1"},{"a":".adv"},{"a":".bannersinglefot"},{"a":"#googlebox"},{"a":"#floatbtmleft,\na[href^=\"//angel4d.com/\"],\na[href^=\"//telolet4d.com/\"]"},{"a":".iklanSUKI"},{"a":".slot-iklan"},{"a":".float_tengah,\n.separator"},{"a":".lenyap"},{"a":".ad-float-image"},{"a":".rsABlock"},{"a":".col-xs-12.col-md-6.col-lg-6"},{"a":"#previewBox"},{"a":".wpb-outer-wrap"},{"a":".bot.ads"},{"a":"#float-pop"},{"a":"#overlay-pop"},{"a":"#fancybox-overlay"},{"a":"[href=\"http://bit.ly/adsvbola\"],\n[id^=\"yui-gen\"].postcontainer"},{"a":".bm.overlay"},{"a":"a.bnner"},{"a":".top-bnner.lazy"},{"a":"[href=\"https://144.126.241.203/invite/c6c83up\"],\n[href=\"https://bit.ly/anoboySG88\"],\n[href=\"https://kliksaya.info/mcdanoboy\"]"},{"a":".adbtm,\n.bh-ad,\n.block-bh-googledfp,\n.center-block.img-responsive"},{"a":".cari-ads"},{"a":"#Taboola_widget,\n#rec_ad4,\n.tonal__standfirst"},{"a":".adplaceholder-mrec"},{"a":".code-block-6,\ndiv[data-ub-carousel]"},{"a":"#sadl,\n#sadr"},{"a":".ktz_banner"},{"a":"#sct_banner_top,\n#videoad1"},{"a":".ads-header-5"},{"a":"#bmpop_adpB"},{"a":".placeholder-container:has(.ads-container)"},{"a":"img.aligncenter"},{"a":".cfmonitor"},{"a":"#banner-popup-desktop"},{"a":".idmupi-topbanner"},{"a":"#banner-right"},{"a":".clearfix.act2-970x90:nth-of-type(1),\n.clearfix.act2-970x90:nth-of-type(3)"},{"a":"img[width=\"1020\"][height=\"350\"]"},{"a":"#semprot_ads_side_left,\n#semprot_ads_side_right"},{"a":"#jsemrp_372_719,\n#jsemrp_373_873,\n#jsemrp_374_469,\n#jsemrp_380_290"},{"a":".semprotpokemon_1,\n.semprotpokemon_2"},{"a":".coliklan"},{"a":".cm-popup-modal"},{"a":".banner3"},{"a":".blox"},{"a":"#floatads2,\n#floatads3"},{"a":".anuads"},{"a":"a[title^=\"manga4d\"]"},{"a":"#openpopunder"},{"a":".mvic-btn"},{"a":".sidebarborder:nth-of-type(4),\n.sidebarborder:nth-of-type(5)"},{"a":"a[href^=\"//bit.ly/\"]"},{"a":"#videoOverAd"},{"a":"#tutup,\n#tutup2"},{"a":"#float-atas"},{"a":".header-banner"},{"a":".swal-overlay--show-modal.swal-overlay"},{"a":".s-sponsor"},{"a":"#popuppress-9119,\n#top-banner-content"},{"a":"#main-popup"},{"a":".banner-middle"},{"a":"[class*=\"banner\"]"},{"a":".teaser3"},{"a":"a[target=\"_blank\"][rel^=\"noopener noreferrer\"] > img[src$=\".gif\"]"},{"a":".kzl-header.kzl"},{"a":".iklan-tengah"},{"a":"[href$=\"/referral/nontoncinema\"],\na[href^=\"http://referral.\"]"},{"a":".box_banner"},{"a":"[href=\"//dumbpop.com/help.xml\"]"},{"a":"#largebanner"},{"a":"table"},{"a":"#text-30 > .textwidget,\n#text-6 > .textwidget"},{"a":"#ffbp-bg,\n#ffbp-body,\n#ffbp-close"},{"a":"[href^=\"http://linkalternatif.\"],\n[href^=\"https://tinyurl.com/\"]"},{"a":"a[rel^=\"nofollow noopener\"] > img[src$=\".gif\"]"},{"a":"#ffbp,\n#popup"},{"a":".add,\n.mobi.content-left,\n.mobi.content-right"},{"a":"#wpb_overlay,\n.wpb-image-popup.wpb-main-wrapper"},{"a":"#epmblock,\ndiv:nth-of-type(2) > div > .btn-block.btn-lg.btn-success.btn"},{"a":".hidden-xs"},{"a":".page > div:nth-of-type(4) > div:nth-of-type(1),\ndiv:nth-of-type(4) > div:nth-of-type(2)"},{"a":".av-content-full,\n.glx-link,\n.glx-teaser"},{"a":"[href=\"http://sbovn88.net/\"]"},{"a":".adsincenter"},{"a":"#ftadsth"},{"a":"#player-side-left,\n[href=\"https://indoxplay.com/promosi/slots\"]"},{"a":"#home-bnner-content"},{"a":"#home-bnner2-content,\n.reklam-goster-sag,\n.reklam-goster-sol"},{"a":"#directorio > .random > center"},{"a":"#sidebar_right > .side:nth-of-type(5) > .textwidget,\n#sidebar_right > .side:nth-of-type(6) > .textwidget,\n#sidebar_right > .side:nth-of-type(7) > .textwidget,\n#sidebar_right > .side:nth-of-type(8) > .textwidget,\n#sidebar_right > .side:nth-of-type(9) > .textwidget"},{"a":".bannerwrap"},{"a":"#previewBox1"},{"a":"#top-bnner-content"},{"a":".ads-big,\n.ads-foot,\n.ads-right2,\n.container_skinad,\n.mgidclsbanner"},{"a":".fancybox-skin"},{"a":".navbar-brand.bot,\ndiv[id^=\"previewBox\"]"},{"a":".ads728-slot-panjang"},{"a":".banner-premium"},{"a":"[class=\"sc__wrp\"]"},{"a":"[href^=\"http://enakbet.link/\"]"},{"a":"#floatbottom,\n.adsrow,\n.gambarku,\n[href=\"http://www.70284385.com/id-id/betting.aspx\"]"},{"a":".tutup.banner"},{"a":"#content > div:nth-of-type(1)"},{"a":"#sgpb-popup-dialog-main-div-wrapper,\n.sg-popup-builder-content"}];

const hostnamesMap = new Map([["anoboy.digital",0],["anoboy.media",[0,77]],["22cinema.download",1],["oploverz.fan",2],["dunia21s.fun",3],["lk21.li",[3,67]],["fb21.tv",[3,149]],["nonton21.tv",[3,67]],["lk21c.fun",4],["lk21.host",5],["animeindo.id",6],["apkmod.id",7],["radarlombok.co.id",7],["novelgo.id",7],["paraedu.id",7],["hightech.web.id",[7,53]],["nama.web.id",7],["batch.id",8],["budiarto.id",9],["ceklist.id",10],["alona.co.id",11],["cerpen.co.id",12],["chip.co.id",13],["cosmogirl.co.id",14],["anime17.net",[14,84]],["dream.co.id",15],["kaskus.co.id",16],["kontan.co.id",17],["pusatdata.kontan.co.id",18],["stocksetup.kontan.co.id",19],["lihat.co.id",20],["orami.co.id",21],["pontianakpost.co.id",22],["republika.co.id",23],["viva.co.id",24],["log.viva.co.id",25],["wartaekonomi.co.id",26],["filmterbaru.id",27],["ggwp.id",28],["grid.id",29],["nextren.grid.id",30],["www.grid.id",31],["inews.id",32],["www.inibaru.id",33],["investor.id",34],["jurnalisindonesia.id",35],["kabargames.id",36],["manganime.id",37],["medcom.id",38],["onlinemetro.id",39],["www.sonora.id",40],["tek.id",41],["terasjakarta.id",42],["terkini.id",43],["tirto.id",44],["uzone.id",45],["internetpositif.uzone.id",46],["animeindo.web.id",47],["animeindo.video",47],["animekompi.web.id",48],["cinemaindo.web.id",[49,50]],["sinemaindo.web.id",[49,59]],["filmbagus21.info",50],["eka.web.id",51],["ganool.web.id",52],["kazefuri.web.id",54],["lk21.web.id",55],["mangaku.web.id",56],["mangaku.in",56],["mangaku.site",[56,142]],["nontonmovie.web.id",57],["videocrot.org",[57,129]],["resep.web.id",58],["suki48.web.id",60],["zigi.id",61],["manganime.in",62],["b201.info",63],["senimovie.info",[64,65]],["senimovies.net",64],["ganool.is",66],["ganool.ph",66],["ganool.se",[66,136]],["ganool.st",66],["nontonlk21.live",68],["bioskop99.me",69],["dunia21.me",[70,71]],["dunia21.net",71],["dunia21.org",71],["dunia21.wtf",71],["idfl.me",[72,73]],["r-l.me",72],["idtube.me",[74,75]],["idxx1.top",[75,143]],["xx1.me",76],["bharian.com.my",78],["mforum.cari.com.my",79],["utusan.com.my",80],["mediahiburan.my",81],["rasa.my",82],["youtube-mp3.my",83],["animeindo.net",85],["awnime.net",86],["bintangmawar.net",87],["briliofood.net",88],["cinema-indo.net",89],["dramaqu.net",90],["duniaku.net",91],["filmace21.net",92],["filmbagus88.net",93],["filmku.net",94],["funtasticko.net",95],["gadismalam.net",96],["harakahdaily.net",97],["ibugil.net",98],["indoxxi.net",99],["inidramaku.net",100],["juragan-anime.net",101],["kazefuri.net",102],["komiku.net",103],["kurazone.net",104],["mangakita.net",105],["mangashiro.net",106],["nobarfilm21.net",107],["nontonganool.net",108],["seri168.net",109],["torjack.net",110],["tvkabel.net",111],["unyil.net",112],["zonapanaz.net",113],["indobokep.pro",113],["dutafilm.observer",114],["bokepml.online",115],["layarxxi.online",116],["dewabioskop21.org",[117,118]],["dwa21.org",[117,119]],["film21terbaru.org",120],["gatsunime.org",121],["kumpulmanga.org",122],["nanimex.org",123],["nontoncinema.org",124],["otakuindo.org",125],["pakbos21.org",126],["pkspiyungan.org",127],["satujiwa.org",128],["indoxxi.pictures",130],["bioskop168.pro",131],["otakudesu.pro",132],["indoxx1.pw",133],["file.rocks",134],["lonteku.sbs",135],["cmovieshd.se",[136,137]],["hdfree.se",138],["myasiantv.se",139],["filmbokep21.shop",140],["ganol.si",141],["mangaku.vip",142],["indoxxi.top",[144,145]],["indoxxi.tv",[144,150]],["bioskopmovie.tv",146],["cinemaindo.tv",147],["elde.tv",148],["xx1.tv",150],["kompas.tv",151],["layarkaca21.tv",152],["lk21.tv",152],["ns21.tv",153],["ns21.us",153],["drakorasia.us",154],["dewanonton.vip",155],["kurina.vip",156],["otakudesu.watch",157],["samehadaku.win",158],["goblintv.xyz",159],["indostreamings.xyz",160],["kazemanga.xyz",161]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
