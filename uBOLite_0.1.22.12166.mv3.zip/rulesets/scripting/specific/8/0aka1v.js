/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// ita-0

const argsList = [{"a":".vc_custom_1621492912685"},{"a":".banner-top-left,\n.banner-top-right,\n.content-banner-right"},{"a":"img[width=\"300\"][height=\"252\"],\nimg[width=\"300\"][height=\"289\"],\nimg[width=\"300\"][height=\"90\"],\nimg[width=\"315\"][height=\"150\"]"},{"a":"#Banner"},{"a":".bn-header"},{"a":".no_pop"},{"a":".alert.alert-success"},{"a":"div[id^=\"article-desk-after-header-ad_\"],\ndiv[id^=\"article-desk-before-footer-ad_\"]"},{"a":"div[style=\"width: 300px; height: 260px; margin-top: 10px;\"]"},{"a":"#nwg"},{"a":".carte-post-1"},{"a":".banner_tab380"},{"a":".bannerh,\n.mh-footer"},{"a":".wp-block-product-on-sale"},{"a":"#wn-insurance-quote-editor"},{"a":".ziobox"},{"a":"#skin_link_dx,\n#skin_link_sx,\n.skin_link_top"},{"a":"#text-31"},{"a":".hijau"},{"a":".primobanner-320,\n.widget_realty_widget,\nAMP-IMG[width=\"320\"][height=\"50\"],\nimg[height=\"300\"][width=\"250\"]"},{"a":".post-div-banner-sp-medium"},{"a":".slide-image"},{"a":"a[href*=\"//altadefinizione-4k-ita.php\"]"},{"a":"a[href*=\"//streaming-ita.php\"],\na[href*=\"/scaricare-film.php\"]"},{"a":"a[href*=\"/streaming-gratis.php\"]"},{"a":".bbtn"},{"a":"div[id^=\"tribu-\"]"},{"a":".socia-adlabel"},{"a":".guardasingle"},{"a":"#fpub-popup"},{"a":"div[style=\"width:970px; height:250px; margin:20px auto; float:left;\"]"},{"a":"a[href*=\"/scar.php\"]"},{"a":"iframe[style*=\"z-index: 2147483647\"]"},{"a":"#banner2"},{"a":".big_box"},{"a":".elementor-element-e5738ed"},{"a":".tdi_118,\n.tdi_144"},{"a":".pull-left,\n.pull-right"},{"a":".box-tva,\n.news-sponsorizzate"},{"a":"#sezpartnercommerciali,\n.partner2"},{"a":"a[href^=\"https://www.aliperme.it/\"]"},{"a":".navbar-purina-red"},{"a":".pre_footer"},{"a":".publis-bottom"},{"a":"#leader-left2"},{"a":".widget-banner-container"},{"a":"#panel-2-4-3-1,\n#panel-2-4-3-3"},{"a":".container-ads,\n.container-skin"},{"a":".banner_single_top"},{"a":"a[href^=\"https://iptv01.tw/\"]"},{"a":".hp__banner"},{"a":"a[href*=\"/HD/\"]"},{"a":".other_link2"},{"a":".guarda"},{"a":".client_logos,\n.home_sponsor,\n.inner_left_top"}];

const hostnamesMap = new Map([["pangea.news",0],["torresette.news",1],["umbriaoggi.news",2],["direttagol.one",3],["giornal.one",4],["filmpertutti.onl",5],["pagare.online",6],["aleteia.org",7],["incircolo.altervista.org",8],["anteritalia.org",9],["carteprepagate.org",10],["fidaf.org",11],["filmforlife.org",12],["fitnesspalestra.org",13],["guidaviaggi.org",14],["ilmigliore.org",15],["iovivoaroma.org",16],["lamiavitainvaligia.org",17],["mathadvantage.org",18],["nursetimes.org",19],["sslazio.org",20],["unimondo.org",21],["altadefinizione01.page",22],["filmstreaming.page",23],["piratestreaming.page",24],["altadefinizione4k.tv",[24,31]],["guardaserie.skin",25],["tribunapoliticaweb.sm",26],["gas.social",27],["ilgeniodellostreaming.to",28],["1web.tv",29],["adessoin.tv",30],["animelove.tv",32],["cataniapubblica.tv",33],["ilcaffe.tv",34],["ilsalottodelcalcio.tv",35],["jamma.tv",36],["lostrillone.tv",37],["montagna.tv",38],["msmotor.tv",39],["padovasport.tv",40],["petpassion.tv",41],["pisachannel.tv",42],["prendiporno.tv",43],["pupia.tv",44],["supertennis.tv",45],["tgtourism.tv",46],["tiburno.tv",47],["tutto.tv",48],["calcio.tw",49],["vaticannews.va",50],["ilgeniodellostreaming.vin",51],["eurostreaming.vote",52],["eurostreaming.voto",53],["umbria.webcam",54]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
