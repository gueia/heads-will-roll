/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// spa-0

const argsList = [{"a":"#gift-middle"},{"a":"[id^=\"gift-\"]"},{"a":"#gift-top"},{"a":"span[style=\"font-weight:bold; cursor:pointer; text-decoration:underline\"]"},{"a":"a[href*=\"leadzupc.com/\"]"},{"a":"#closeX2"},{"a":".branding-wrapper"},{"a":".advertisement,\n.widget_ti_image_banner"},{"a":"a[href*=\"clicktag_promo\"]"},{"a":".grid_12 > .grid_4"},{"a":"a[href^=\"http://www.maxonclick.com/\"]"},{"a":"#promo,\n#promoSept19A,\n#promoSept19B,\n.promoTop"},{"a":"#bottomlink,\n#categories"},{"a":"a[href^=\"https://veranime.org/\"]"},{"a":".banners-side-container,\na[href=\"http://www.180.com.uy/banner?ID=857&CODE=portal.index\"]"},{"a":".auspicios,\n.modulo_publi"},{"a":"#conectab"},{"a":"#bannerEspeciales,\n#clima-banner"},{"a":".bfbc"},{"a":".bnpub"},{"a":".vjs-producer"},{"a":"[href^=\"https://qp.erotilink.es\"]"},{"a":".lst_ft_bn"}];

const hostnamesMap = new Map([["ev01.to",0],["moviesjoy.to",1],["myflixertv.to",2],["seriesdanko.to",3],["animeid.tv",4],["cinestrenostv.tv",5],["eldoce.tv",6],["jerezcofrade.tv",7],["mundoplus.tv",8],["ondaluz.tv",9],["pelisplus.tv",10],["qmusica.tv",11],["shippuden.tv",12],["genteflow.us",13],["180.com.uy",14],["elobservador.com.uy",15],["montevideo.com.uy",16],["pantallazo.com.uy",17],["juegosjuegos.ws",18],["maduras.xxx",19],["videos.mrvideospornogratis.xxx",20],["qporno.xxx",21],["tupornogratis.xxx",22]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
