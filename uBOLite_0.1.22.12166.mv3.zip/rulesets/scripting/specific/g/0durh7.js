/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// nld-0

const argsList = [{"a":".branded-countdown__content__partner-wrapper,\n.homepage-casino-wrapper"},{"a":".eskimo-carousel-container"},{"a":".module_round_box"},{"a":".hoofdAd2"},{"a":".codalt-container,\n.infotainment:has(a[href^=\"/advert\"]),\n.rdnl__adds"},{"a":"section:has(.item-banner)"},{"a":".bannercontainer"},{"a":"img[width=\"300\"][height=\"100\"]"},{"a":".regio-widget"},{"a":".td-a-rec"},{"a":"#advertisement"},{"a":".widget_itarget_banners"},{"a":".carousel"},{"a":"[id^=\"gtm-article-lb\"],\n[id^=\"gtm-article-mpu\"]"},{"a":"aside > .textwidget [src*=\"wp.com/romagazine.nl/\"][src*=\"/wp-content/uploads/\"][src$=\"?w=665\"]"},{"a":"img[title^=\"roba_sponosor_\"]"},{"a":".list-sponsors"},{"a":"div[style*=\"width:730px; height:90px;\"]"},{"a":".dfp-rectangle-wrapper"},{"a":"#dfp-billboard-wrapper,\n.rtldart"},{"a":".article-sidebar__ad,\n.dfp-billboard-wrapper,\ndiv[class$=\"_with_ad__ad\"]"},{"a":"#recommendations-above-ad,\ndiv[class^=\"col\"]:has([class*=\"adcontainer\"])"},{"a":"#advertenties,\n#advertentiesOnder"},{"a":".footeradd"},{"a":".art-positioncontrol"},{"a":".avia-content-slider1"},{"a":".partnerlink"},{"a":".row > [class]:has(.sfr-pdp-section[id$=\"crossseller\"])"},{"a":"#block-leaderboard,\n#block-topbannersidebar"},{"a":"#media_image-3,\n#media_image-4"},{"a":".widget_minisites"},{"a":".et_pb_text:has(* > .g):not(:has(.heading-more)),\n[href^=\"https://dt51.net/\"],\ngofollow:has(img[src])"},{"a":"[id^=\"sgpb-popup-dialog\"]:has(iframe[src^=\"https://www.affilaxy.com/promos/\"]),\n[id^=\"sgpb-popup-dialog\"]:has(iframe[src^=\"https://www.affilaxy.com/promos/\"]) + [class]"},{"a":".videoOverAdBig"},{"a":"[id^=\"custom_html-\"]:has(iframe[data-src*=\"jygotubvpyguak.com\"])"},{"a":".entry-content > div"},{"a":"#recommendBlock,\n[href^=\"https://ads.v1d305.com/redirect/\"]"},{"a":".blogBanners,\n.topBanners"},{"a":".banner-wrapper,\ndiv[id^=\"banner-\"]"},{"a":".widget_custom_html:has([src*=\"affilaxy.com\"]),\n.widget_media_image:has(img[src*=\"sexmeid.nl/wp-content/uploads/\"][src$=\".gif\"])"},{"a":"#pre-footer-banners,\n#top-banner"},{"a":"#top:has(.banner)"},{"a":"[id^=\"text\"]:has([src^=\"https://www.shespot.nl/wp-content/uploads/\"])"},{"a":"section:has(div[class$=\"sponsors\"])"},{"a":".holder-ads"},{"a":"#r89-mobile-rectangle-mid,\n#r89-takeover,\n.bcb-sport-block-data"},{"a":".sam-slot"},{"a":".sols,\n[id]:has(.company-add)"},{"a":".adchannel"},{"a":".logo_main_sponsor_image,\n.logo_slider_logos"},{"a":".banner-btf-side-rectangle,\n.banner-sky,\n.leader-below-game"},{"a":".game-page-sidebar"},{"a":".widget_text.gridlove-box"},{"a":".spel_b1,\n.spel_b2"},{"a":".widget_media_image:not(:has(img[src*=\"vierkant-spreekbuis\"])),\n.widget_spreekbuis_partners"},{"a":"aside.widget:has(a[href*=\"trff9links.com/\"])"},{"a":".advertentieblock"},{"a":".top-banner"},{"a":".wp-block-buttons"},{"a":"[class$=\"-banners-wrapper\"]"},{"a":".creatividad"},{"a":"#lead"},{"a":".ArticleBodyBlocks__bannerWrapper,\n.ArticlePageWrapper__banner,\n.Banner,\n.ComponentRotation,\n.MainCuratedTeasersLayout__banner,\n.SectionPage__bannerWrapper,\n.SportScoreboardPage__banner,\n.TextArticlePage__bannerWrapper,\n.VideoArticlePage__banner,\n.VideoPage__banner,\n.WebpushOptin__main,\n.withBanners,\n.withBanners + .ComponentRotation"},{"a":"#lb_header"},{"a":"[href=\"https://www.domasmsuite.nl\"]"},{"a":"aside[id^=\"block\"]:has(img[src*=\"/wp-content/uploads/\"][src$=\".gif\"])"},{"a":".theme-advertorial"},{"a":"[href^=\"https://www.totaaltv.nl/plugins/banner/\"]"},{"a":".SponsorBlock"},{"a":".desktopad"},{"a":"[id$=\"halfpage\"],\n[id$=\"top-ad\"],\n[id*=\"r89\"][id$=\"home\"],\ndiv.ads-contain"},{"a":".werbung"},{"a":"[class^=\"ads-adsense-\"]"},{"a":".trucks_ros_alpha_rectangle-halfpage,\n.trucks_ros_leaderboard-billboard"},{"a":".img_position_left:has(.adsbygoogle)"},{"a":".easingslider"},{"a":"div[class^=\"r89-desktop\"]"},{"a":".banner-fluid"},{"a":".square-item:has( > .banner)"},{"a":".adBoxbig"},{"a":"[id^=\"text-\"]:has([href^=\"https://www.eo-acties.nl/TradeTracker/index.aspx\"])"},{"a":"[class^=\"bannerzone_\"]:has([href])"},{"a":"[src^=\"/derden/betcity-\"]"},{"a":".uitgelichtbox"},{"a":"#partner-links,\n.list-item:has(script[src*=\"realsrv\"]),\n[href^=\"https://xltube.nl/click/\"],\n[id$=\"fish-hooks\"],\ndiv[id^=\"video-fish-hook\"]"},{"a":"div[class^=\"Component-bannerTopWrapper-\"]"},{"a":"[href]:has([src*=\"media.prdn.nl\"])"},{"a":"div[id][class^=\"css\"]"},{"a":".betting-provider-row"},{"a":".modal"},{"a":"[href^=\"https://www.anp.nl/start\"]"},{"a":"[class^=\"row advertentie-\"]:not([class*=\"advertentie-1\"])"},{"a":".row [id^=\"form\"] + .box > .box-body:has(img)"},{"a":"[class*=\"right\"] .wpb_wrapper:has(img[height=\"520\"][src])"},{"a":"a[href^=\"https://partner.bol.com/\"],\ndiv[class^=\"col\"]:has([class^=\"add\"])"},{"a":".banner_wrapper"},{"a":"[id*=\"miw_widget\"] a[target$=\"blank\"][href]:not(a[href*=\"mailto\"])"},{"a":"#sidebar_aanbevelen"},{"a":"#submenubanner"},{"a":"[href^=\"https://ads.jacks.nl/redirect.aspx\"]"},{"a":"div[class$=\"sidebar-widget\"] > .textwidget:has(p > a[href*=\"eredivisiewedden.nl\"][target=\"_blank\"])"},{"a":".card-banner,\n.card-banner-large"},{"a":".kolom_haad > div[style=\"height: 300px;\"],\ndiv[style$=\"0px;\"]:has(.adsbygoogle)"},{"a":".sticky-banner-container"},{"a":"#right-sidebar > .mb-3:has(img[src*=\"banner\"]),\n.float-right"},{"a":".rectangle"},{"a":".leaderBoardHolder"},{"a":"div[class^=\"r89-desktop-rectangle\"]"},{"a":"div[class^=\"styled__AdWrapper-\"],\ndiv[class^=\"styled__FooterAdWrapper-\"]"},{"a":".hf-widget"},{"a":".cookieconsent-optin-marketing"},{"a":".banner-right,\n.infeed-outer,\n.infeed-wrap"},{"a":".content-start > :has([advobject])"},{"a":".post:has(a[href*=\"/partnerposting/\"])"},{"a":"#ad-takeover"},{"a":".adr-wrapper"},{"a":"#reclame,\n.advertentieBanner"},{"a":"li.ipsBox.ipsWidget:has(.ipsType_richText.ipsPad)"},{"a":".widget_media_image:not(:has(a[href^=\"https://wijkkrantzuid.nl\"]))"},{"a":"[class*=\"avia-image-container\"]:has(a[href]),\n[id*=\"after_section\"] > .container:has([class*=\"av-content\"]),\nimg[width=\"699\"][height=\"90\"]"},{"a":"#block-views-block-view-business-partners,\n#block-views-block-view-main-sponsor,\n#block-views-block-view-shirt-sponsor,\n.top-bar-logos"},{"a":"[href=\"https://www.loketkansspel.nl/\"]"},{"a":".header-right"},{"a":".bs"},{"a":".container-linkpartners,\n.rightbar > :has([src^=\"https://ads.\"])"},{"a":"#reclame-eroads"},{"a":"[id^=\"block-block\"]:has([id^=\"div-gpt-ad\"]),\ndiv[class*=\"block-block\"]:has(.adsbygoogle),\ndiv[style*=\"padding:10px\"]:has(div[id^=\"div-gpt-ad\"])"},{"a":".article-bnr-first,\n.as__bottom-banner,\n.g_banner,\n.row--bnr-between,\naside:has([id^=\"div-gpt-ad\"])"},{"a":"div[class^=\"display-ad_container\"]"},{"a":"#banner_rectangle,\n#banner_right,\n#banner_top"},{"a":"#leaderboard"},{"a":"div[style]:has(.adsbygoogle)"},{"a":"aside[class^=\"td_block\"]:has(.gofollow)"},{"a":".ult-content-box > a[href]:not([href*=\"nieuwsfiets.nu\"]):not([href*=\"questionpro.com\"]),\n.wpb_raw_html[class*=\"us_custom_\"]:has(.wpb_wrapper)"},{"a":".clearfix:has(img[src*=\"/header/\"])"},{"a":"[class^=\"my-\"]:has(img[src*=\"/images/banner/\"])"},{"a":".adsbygoogle,\n.td-adspot-title"},{"a":".ads-mobiel"},{"a":".widget_block:has(img[src*=\"/ad\"]),\n.wpa"},{"a":".product__wrapper:has(.adsbygoogle)"},{"a":".widget:has(.capegroep-banner)"},{"a":"a[href^=\"https://www.onlinebingokaart.nl/\"]"},{"a":"div[style*=\"width:300px; height:200px;\"],\ndiv[style*=\"width:300px; height:250px;\"],\ndiv[style^=\"width:300px; height:180px;\"]"},{"a":"#image-vertical-reel-scroll-slideshow,\n.slider-container"},{"a":".col-left,\n.col-right"},{"a":".holder--divider-top"}];

const hostnamesMap = new Map([["racingnews365.nl",0],["radiocontinu.nl",1],["radioeenhoorn.nl",2],["radiofm.nl",3],["rd.nl",4],["reformatorischeomroep.nl",5],["refoweb.nl",6],["regio-voetbal.nl",7],["regionoordkop.nl",8],["regioonline.nl",9],["rickfm.nl",10],["riskcompliance.nl",11],["rkcwaalwijk.nl",12],["rodi.nl",13],["romagazine.nl",14],["rotterdambasketbal.nl",15],["roulettefm.nl",16],["rtvstichtsevecht.nl",16],["routenet.nl",17],["rtlboulevard.nl",[18,19]],["rtlnieuws.nl",[18,20]],["rtvdrenthe.nl",21],["rtveen.nl",22],["rtvgo.nl",23],["rtvkrimpenerwaard.nl",24],["salvora.nl",25],["sc-heerenveen.nl",26],["schaefer-shop.nl",27],["scheepvaartkrant.nl",28],["schiedamsnieuws.nl",29],["schuttevaer.nl",30],["seksmet.nl",31],["seksverhalen.nl",32],["sex-kamer.nl",33],["sexcam-mokkels.nl",[34,35]],["tellows.nl",[35,63]],["sexfun.nl",36],["sexguide.nl",37],["sexjobs.nl",38],["sexmeid.nl",39],["sexpower.nl",40],["sexpunt.nl",41],["shespot.nl",42],["simone.nl",43],["slam.nl",44],["soccernews.nl",45],["softonic.nl",46],["solarmagazine.nl",47],["sozio.nl",48],["sparta-rotterdam.nl",49],["speeleiland.nl",50],["spel.nl",51],["spelletjes.nl",51],["spelersvrouw.nl",52],["spidersolitairespelen.nl",53],["spreekbuis.nl",54],["sproeiendekutjes.nl",55],["startlijstjes.nl",56],["startpagina.nl",57],["streamwijzer.nl",58],["streekstadcentraal.nl",59],["tameteo.nl",60],["techzine.nl",61],["telegraaf.nl",62],["thekinkyweb.nl",64],["tiener-sexverhalen.nl",65],["topgear.nl",66],["totaaltv.nl",67],["totoknvbbeker.nl",68],["touretappe.nl",69],["tpo.nl",70],["transfermarkt.nl",71],["treinreiziger.nl",72],["trucks.nl",73],["turkinfo.nl",74],["turksemedia.nl",75],["tvblik.nl",[76,77]],["voetbalrotterdam",76],["tvgids.nl",78],["tvgids24.nl",79],["tweedehandschristelijkeboeken.nl",80],["twentefm.nl",81],["ucl-voetbal.nl",82],["uecl-voetbal.nl",83],["uel-voetbal.nl",83],["vagina.nl",84],["vandaaginside.nl",85],["vastgoedjournaal.nl",86],["veronicasuperguide.nl",87],["vi.nl",88],["video18.nl",89],["villamedia.nl",90],["visserijnieuws.nl",91],["vitesse.nl",92],["vives.nl",93],["vlaamskijken.nl",94],["vlietnieuws.nl",95],["vlootschouw.nl",96],["voetbal-vandaag.nl",97],["voetbalnederland.nl",98],["voetbalprimeur.nl",99],["voetbalsnafu.nl",100],["volleybal.nl",101],["waldnet.nl",102],["want.nl",103],["wanttoknow.nl",104],["wasmachines.nl",105],["webwereld.nl",106],["webwoordenboek.nl",107],["weeronline.nl",108],["weerplaza.nl",109],["weerstationleeuwarden.nl",110],["weertdegekste.nl",111],["weespernieuws.nl",112],["welingelichtekringen.nl",113],["welklidwoord.nl",114],["westerwoldeactueel.nl",115],["wettelijke-feestdagen.nl",116],["wietforum.nl",117],["wijkkrantzuid.nl",118],["wildfm.nl",119],["willem-ii.nl",120],["wkdarts.nl",121],["wos.nl",122],["xgn.nl",123],["xmissy.nl",124],["xxxdump.nl",125],["zakenreisnieuws.nl",126],["zeelandnet.nl",127],["zoom.nl",128],["afkortingen.nu",129],["eindexamens.nu",130],["landbouwgrond.nu",131],["newspower.nu",132],["nieuwsfiets.nu",133],["nieuwsonline.nu",134],["schie.nu",135],["dissident.one",136],["dorpsklanken.online",137],["eindtijdklok.org",138],["letsgodigital.org",139],["nljug.org",140],["omrekenen.org",141],["apintie.sr",142],["unitednews.sr",143],["tvgids.tv",144],["basketbal.vlaanderen",145]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
