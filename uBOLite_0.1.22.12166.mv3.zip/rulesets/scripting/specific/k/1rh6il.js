/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// fra-0

const argsList = [{"a":"#banner2"},{"a":".pub-medium"},{"a":".rbanner-wrap,\n.vbanner-wrap"},{"a":"form > center > a[href*=\".php\"]"},{"a":"a[href*=\".html\"],\na[href^=\"/regarder\"]"},{"a":"a[href=\"https://fcstream.com/player.html\"] > img,\na[href^=\"http://bit.ly/\"][rel=\"nofollow\"] > img,\na[href^=\"https://fcstream.com/banniere\"]"},{"a":"#box-link-left,\n#box-link-right,\n#extruderLeft1,\n.bgTGC,\ndiv[style=\"margin-top:5px;float:auto;width:100%;height:250px;text-align:center\"]"},{"a":"a[href^=\"https://dl-protect.net/get-premium-url?\"] > img"},{"a":"#region-user-second,\n.generic-atomic"},{"a":"annonces-post-detail:has(.bg-boosted)"},{"a":"div[style*=\"height:90px;\"][style*=\"728px\"]"},{"a":"a[href^=\"http://clic.reussissonsensemble.fr/click.asp?\"]"},{"a":"body > center + #layer2"},{"a":"[style*=\"position: absolute; z-index: 99999\"]"},{"a":".widget-5"},{"a":".privacylinks"},{"a":"#gauche > iframe[width=\"300\"][height=\"250\"]"},{"a":"#bannerTopWrapper"},{"a":".ads--insertor-casper"},{"a":".pub-content"},{"a":"a[href^=\"https://href.li/\"]"},{"a":"td[align=\"left\"][colspan=\"3\"] > div[style=\"width:70%;\"]"},{"a":".publi"},{"a":".alert-warning"},{"a":"iframe[width=\"300\"][height=\"250\"],\niframe[width=\"728\"][height=\"90\"]"},{"a":"a[href^=\"/geturl\"] > img"},{"a":"#background-promo,\n.p-sky,\n.top-pub"},{"a":".gtag"},{"a":".tradeDoubler"},{"a":"a[href*=\"http://www.liutilities.com/aff\"]"},{"a":".samBannerUnit"},{"a":"a[href^=\"https://ahegao.fr\"],\na[href^=\"https://drmanga.net\"]"},{"a":".pub_large"},{"a":".pubbas"},{"a":".adsl"},{"a":".top-bar"},{"a":"#pub0,\n#pubz"},{"a":".articleText > .large_rectangle"},{"a":"#ExpoPermanente"},{"a":"a[href^=\"LienExterne.asp?\"]"},{"a":"div[id^=\"sas_\"]"},{"a":"#lastBar,\n.homePub,\ndiv[style=\"overflow: hidden; width: 336px; height: 280px; margin: 0 auto;\"]"},{"a":"#lpn_pub_main,\n.blockShopping"},{"a":"#jobat_content,\n.footer--partners"},{"a":"#header_content_banner"},{"a":"a[target=\"_blank\"] > img[width=\"300\"][height=\"100\"],\na[target=\"_blank\"] > img[width=\"300\"][height=\"200\"]"},{"a":".layout-grid__banner-top,\n.subscription-prompt,\na[href^=\"/blogsecretdefense/ads/\"]"},{"a":"a[href^=\"http://www.meetmuslima.net/go/\"]"},{"a":"#imCell_259,\n#imStickyBar_imObjectButton_03,\na[href^=\"https://www.clictune.com/\"],\na[style*=\"width: 98%; height: 100%; inset:\"]"},{"a":"#smart-bann"},{"a":".headertitrelien[target=\"_blank\"]"},{"a":"#common-top-widget,\na[href^=\"http://ads.oujdacity.net/\"]"},{"a":"#footer"},{"a":"div[style=\"width:300px;height:600px;\"]"},{"a":".dynInFeed,\n.pstAd"},{"a":"#campain_bg"},{"a":"a[href*=\"/?ad=\"]"},{"a":"#presse_citron_skin,\n#presse_citron_skin_banner,\n.plan-list"},{"a":".bloc-header-play,\n.container-pave-haut-sidebar,\n.shopping"},{"a":".mega-banner"},{"a":"#adBlockBnr,\n.adcontent,\n[class^=\"vda-\"]"},{"a":"#tplInstallNow + .install-now,\na[id][href][target][style]"},{"a":"#shadow,\n.sonicprice,\n.webrox._300x250.centered"},{"a":"a[href*=\"/affiliate-\"] > img"},{"a":".pub_ra,\na[href=\"http://www.bleuhabitat.fr/\"] > img"},{"a":"#amazonLink,\n.module.moduleBoutiqueEncart"},{"a":"#bgclicable"},{"a":"a[href^=\"http://www.rpjf.com/asp/lien.asp?\"]"},{"a":".item[style],\nbody > div + .row.align-center.section"},{"a":"[class*=\"pico-\"]"},{"a":"a[href^=\"http://www.bitdefender.fr/media/\"]"},{"a":".block_news_main_pub,\n.header_logo + div > table tr > td > a[target=\"_blank\"],\ndiv[id][onclick][style]"},{"a":".in-block,\n.wait_buffer"},{"a":"a[href*=\"?title=\"]"},{"a":"#chaussuresCarousel"},{"a":"#leader-small,\na[href*=\"/?utm_source=\"]"},{"a":".post--0"},{"a":".mvic-btn"},{"a":"#partner_content,\n.pubDroite"},{"a":".pub_logo,\na[href^=\"http://www.dzsat.org/forum/rbs_banner.php?\"]"},{"a":".affichier_lien > tbody > tr + tr[class],\n.ip-warning"},{"a":"#skinlink"},{"a":"#vpnvpn"},{"a":"div[style*=\"float:right;width:300px;\"]"},{"a":"a[href=\"http://www.jeddl.org/Regarder-le-film.html\"],\na[href=\"http://www.jeddl.org/Telecharger-le-film.html\"],\na[href^=\"//www.jeddl.org/telechargement-film.php?\"]"},{"a":".adtitle"},{"a":"a.homepage_background"},{"a":".m_amazon_product_bloc"},{"a":"img[width=\"300\"][height=\"300\"],\nimg[width=\"600\"][height=\"62\"],\nimg[width=\"692\"][height=\"100\"],\nimg[width=\"692\"][height=\"85\"],\nimg[width=\"695\"][height=\"86\"],\nimg[width=\"740\"][height=\"161\"],\nimg[width=\"740\"][height=\"185\"],\nimg[width=\"800\"][height=\"150\"]"},{"a":"#titre_librairie,\n.sample-lst,\ndiv[style=\"margin-bottom:15px;\"] > table > tbody"},{"a":".bloc_evt,\ndiv[id^=\"programme-televisionorg_\"][id$=\"_ar\"].cmi_pSticky:empty"},{"a":"#pubSky,\n#pubSky2"},{"a":"a[href*=\"&pos=\"]"},{"a":"table[width=\"728\"]"},{"a":"div[style*=\"text-align: center\"][style*=\"width:250px\"]"},{"a":".liketable"},{"a":".bloc_promomiddle"},{"a":"a[href^=\"javascript:\"]"},{"a":"#ads_tall"},{"a":".bnr"},{"a":".iad"},{"a":".rightside > .blocks > .dbtm > center > a[href][target=\"blank\"] > img,\n.rightside > center > a[href][target=\"blank\"] > img"},{"a":"#contenedor > div[class] > a[target=\"_blank\"],\n#plyb"},{"a":"a[href^=\"ads/\"]"},{"a":"#headbanner"},{"a":"#micontenedor > div#total"},{"a":"#adress_utiles"},{"a":"#vjs-overlayclip-container-box"},{"a":".ad-alert-wrapper"},{"a":".col-player > div[style^=\"position:relative; width:100% !important;\"]:not([class]):not([id])"},{"a":"a[href^=\"https://cutt.us/\"]"},{"a":".mvic-btn > a.btn-successful,\ndiv[id^=\"gothamadblock_\"]"},{"a":".movie-aye,\na[href=\"/streaming-video.html\"]"},{"a":".megabanhome"},{"a":"#download_div2"},{"a":".series-player > #bd_sp"},{"a":"a[onclick^=\"openAuc\"]"},{"a":".video-fake"},{"a":"a[href^=\"/go.php?\"][target=\"_blank\"] > img"},{"a":"ad-host"},{"a":".block-mozaic-pub,\n.video-preroll"},{"a":".pop_parent"},{"a":"[class^=\"pub\"]"},{"a":"#pubBaniereContainer,\n#pubIlotContainer"},{"a":"#point_part"},{"a":"#bigBox"},{"a":"div[class*=\"publicite-\"]"},{"a":"a[href^=\"http://watchfomny.tv/Pop/\"]"},{"a":"a[href*=\"://out.streamcomplet.vet/\"]"},{"a":"#mobile_clic,\n.bgClick,\na[style=\"position: fixed;top: 110px;left: 0;bottom: 0;width: 50%;\"]"},{"a":"#place_holder"},{"a":"#layer1,\n#sidebar > .fstory-content[style=\"text-align:center;\"],\ncenter > .block-violet > center[style=\"font-size:12pt;color:#C420C9;\"]"},{"a":"a[href=\"/telechargement-direct.php\"] > img,\na[href=\"/telechargera.php\"] > img,\na[href^=\"http://seriestreaming.xyz/\"],\na[href^=\"http://www.seriestreaming.xyz/\"]"},{"a":"a[href^=\"https://dl-protect.info/url-premium?\"]"},{"a":"center > a[rel=\"nofollow\"],\ncenter > span > a[rel=\"nofollow\"]"},{"a":".entry > div[style=\"text-align:center;\"] > a[target=\"_blank\"] > img"},{"a":".iframe-area > .iframe-contentserie"},{"a":".affiliate"},{"a":"#horizontal-banner"},{"a":"a#lang_download[href=\"/download\"]"},{"a":"center > a[href=\"/telecharger.php\"]"}];

const hostnamesMap = new Map([["hitradio.ma",0],["lematin.ma",1],["souk.ma",2],["protect-link.me",3],["streaming-series.me",4],["streamonsports.me",5],["moov.mg",6],["zone-telechargement.moe",7],["lexpress.mu",8],["annonces.nc",9],["expresso.1fr1.net",10],["algeriephilatelie.net",11],["all-stadium.net",12],["amvtv.net",13],["analyticsinsight.net",14],["buzzporn.net",15],["centerblog.net",16],["clubpoker.net",17],["commentcamarche.net",18],["constructeurdemaison.net",19],["dailyuploads.net",20],["depannetonpc.net",21],["desdelinux.net",22],["detecteur.net",23],["developpez.net",24],["dl-protect.net",25],["euro-2016-france.net",26],["footmercato.net",27],["forum-actif.net",28],["forum-vista.net",29],["hack-life.net",30],["hentaifr.net",31],["influencia.net",32],["internetparsatellite.net",33],["ipadsl.net",34],["jeretiens.net",35],["jeu.net",36],["jeune-independant.net",37],["journaldelenvironnement.net",38],["kerix.net",39],["lacoccinelle.net",40],["lafermeduweb.net",41],["laposte.net",42],["lavenir.net",43],["lefaso.net",44],["maliweb.net",45],["marianne.net",46],["meetmuslima.net",47],["mega-p2p.net",48],["otaku-attitude.net",49],["ouiounon.net",50],["oujdacity.net",51],["forum.oujdacity.net",52],["paroles.net",53],["passeportsante.net",54],["piwee.net",55],["presse-algerie.net",56],["presse-citron.net",57],["programme-tv.net",58],["radio-m.net",59],["reverso.net",60],["savefrom.net",61],["slappyto.net",62],["sosvirus.net",63],["space-blogs.net",64],["techno-science.net",65],["tennisactu.net",66],["topj.net",67],["trictrac.net",68],["uploaded.net",69],["usbfix.net",70],["vakarm.net",71],["vidoza.net",72],["voirseriestreaming.net",73],["wanarun.net",74],["webactus.net",75],["zebrascrossing.net",76],["allo-streaming.one",77],["cciaf.org",78],["dzsat.org",79],["ed-protect.org",80],["freeonline.org",81],["gktorrents.org",82],["impotsurlerevenu.org",83],["jeddl.org",84],["jeux.org",85],["jeuxvideo.org",86],["marmiton.org",87],["mediaguinee.org",88],["phpsources.org",89],["programme-television.org",90],["remede.org",91],["sante-nutrition.org",92],["forum.softmaroc.org",93],["superphysique.org",94],["trackitonline.org",95],["trackitonline.ru",95],["tv5.org",96],["upload4earn.org",97],["ustart.org",98],["vf-film.org",99],["vf-serie.org",99],["vide-greniers.org",100],["zone-telechargement1.org",101],["zustream.org",102],["ladepeche.pf",103],["classement.pro",104],["playerhd2.pw",105],["clicanoo.re",106],["sibnet.ru",107],["yggtorrent.si",108],["dpstream.site",109],["zone-telechargement1.space",110],["vostfr.stream",111],["zoneseries.stream",112],["realites.com.tn",113],["flashx.to",114],["flashx.tv",114],["fullstream.to",115],["hqq.to",116],["hqq.tv",116],["ninjastream.to",117],["streamonsport.to",118],["coflix.tv",119],["d8.tv",120],["e-wok.tv",121],["fulltv.tv",122],["telequebec.tv",123],["terre.tv",124],["tetesaclaques.tv",125],["ici.tou.tv",126],["watchfomny.tv",127],["streamcomplet.vet",128],["jeu.video",129],["cinemay.vip",130],["filmstreaming1.vip",131],["zone-annuaire.website",132],["zone-telechargement.work",133],["filmz.ws",134],["9divx.theproxy.ws",135],["voirfilms.ws",136],["mvideoporno.xxx",137],["videopornoinceste.xxx",138],["dl-protect.xyz",139],["zone-annuaire.xyz",140]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
