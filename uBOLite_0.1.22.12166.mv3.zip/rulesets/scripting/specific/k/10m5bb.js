/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// isl-0

const argsList = [{"a":".ir-surprise-list"},{"a":".augl-wrapper,\n.augl.augl-size-1018,\n.side-augl-wrapper"},{"a":".widget.widget_media_image"},{"a":".bannergroup"},{"a":".banner-container"},{"a":".banner"},{"a":"div[class^=\"col-\"]:has([class*=\"advertisement-spot-\"])"},{"a":"#footer-netgiro,\n.boughtsmas.box,\n.box.classifedSmas,\n.box.isotopeItem.spaceAugl,\n.netgiroInsuranceSection,\n.slider-wrapper,\ndiv[id*=\"advImg\"]"},{"a":".gardina"},{"a":"#cboxOverlay"},{"a":".forsaugl"},{"a":"#nm_container"},{"a":"#ForsidaBotn,\n#ForsidaMB1,\n#ForsidaMB2,\n.col2,\n.turn"},{"a":"#adinj-2"},{"a":"div[class^=\"ad\"]"},{"a":"#wp_editor_widget-18,\n.widget,\n.widgetizedArea"},{"a":".ad"},{"a":".ad2"},{"a":".strevda"},{"a":"#snppopup-welcome"},{"a":"#like"},{"a":".adw"},{"a":".ad-pos"},{"a":".AuglysingaHnappur"},{"a":"#flexslider3,\n.auglysing_h1,\n.new-ads-slider,\n.new-ads-slider-small,\n.new-auglysing_h2,\n.stod_grein"},{"a":"#slot-668,\n#yfirhaus-ad,\n#yfirhaus-augl,\n.augl,\n.augl-parallax-frontpage,\n.augl-wide,\n.dlk-13,\n.dlk-23,\n.mt-5.mb-5"},{"a":"#floating-box-right,\n#footer_section_1,\n#text_mnky-2,\n#text_mnky-3,\n.g.g-2,\n.g.g-7,\n.su-column.su-column-1-3.su-column-style-1,\n.textwidget,\n.topz"},{"a":"#image-3,\n#text-113"},{"a":"#ctl00_RandomBanner2_divBanner,\n#ctl00_RandomBanner3_divBanner,\n#ctl00_cphMain_Wrapper1_ctl06_divBanner,\n#ctl00_ctl00_cphMain_cphMain_RandomBanner4_divBanner,\n#ctl00_ctl00_cphRullugardina_cphRullugardina_RandomBannerRullugardina_divBanner,\n#skyscrapper,\n#spoton,\n.bp26,\n.bp4,\n.randombanner-upperright"},{"a":".fb_ltr"},{"a":"#imgAuglRight_1,\n#imgAuglRight_4,\n.imgAuglHead,\n.kostad-efni,\n.tdAuglMidja"},{"a":".header_add,\nOBJECT[width=\"300\"]"},{"a":"#sambio-banner,\n#top-banner,\n.ad-tower,\nDIV[style=\"padding: 20px 0; text-align: center;\"]"},{"a":".ad_310.add_marg_20_b"},{"a":".add_top_border.left_floater,\n.head_ad_360x100,\n.left_floater.add_top_border,\n.top_customer_banner,\nIMG[src=\"/thumb/550x200/53d278ef882dd.jpg\"]"},{"a":"#ad-overlay-container"},{"a":".col-item"},{"a":"[id*=\"HeaderAd\"]"},{"a":"#banner-310x400-Right,\n.row.ad"},{"a":"#topadbanner"},{"a":"#banner,\n[href^=\"/is/moya/adverts/\"],\n[id^=\"box_aitem\"],\naside"},{"a":".col-md-8.ad.hausad"},{"a":"#banner1,\n#banner10,\n#banner11,\n#banner12,\n#banner13,\n#banner14,\n#banner15,\n#banner16,\n#banner17,\n#banner2,\n#banner23,\n#banner3,\n#banner4,\n#banner5,\n#banner6,\n#banner7,\n#banner8,\n#banner9"}];

const hostnamesMap = new Map([["icelandreview.com",0],["1819.is",1],["auroraforecast.is",2],["austurfrett.is",3],["bb.is",[4,5]],["sporttv.is",[5,32]],["bilasolur.is",6],["bland.is",7],["dv.is",[8,9]],["krom.is",[8,24]],["eidfaxi.is",10],["clients.ennemm.is",11],["flass.is",12],["foreldrahandbokin.is",13],["frettabladid.is",14],["frettanetid.is",15],["frettatiminn.is",[16,17]],["kjarni.is",16],["hringbraut.is",18],["hun.is",19],["infront.is",20],["ja.is",21],["karfan.is",22],["kki.is",23],["mbl.is",25],["menn.is",26],["pjatt.is",27],["pressan.is",28],["bleikt.pressan.is",29],["skessuhorn.is",30],["smugan.is",31],["spyr.is",[33,34]],["stundin.is",35],["sumarferdir.is",36],["veitingastadir.is",37],["vf.is",38],["visir.is",39],["akureyri.net",40],["eyjar.net",41],["fotbolti.net",42]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
