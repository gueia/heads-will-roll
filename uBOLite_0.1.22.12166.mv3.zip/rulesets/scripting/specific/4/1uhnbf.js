/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// ind-0

const argsList = [{"a":".blog-sidebar .widget_custom_html"},{"a":"#author-bio-widget-1"},{"a":".header-wraper .fullwidthabanner"},{"a":"section[data-id=\"9a0f91e\"]"},{"a":"#secondary section.widget_block"},{"a":".entry-content > p img:only-child"},{"a":"body > .container > .row:first-child > div:last-child"},{"a":"#attachment_10957,\n#attachment_11499,\n#attachment_11653,\n#attachment_12010,\n#attachment_12428,\n#attachment_12691,\n#attachment_12880,\n#attachment_12945,\n#attachment_13381,\n#attachment_13529,\n#attachment_13539,\n#attachment_13549,\n#attachment_13929,\n#attachment_14460,\n#attachment_15074,\n#attachment_15085,\n#attachment_15191,\n#attachment_16388,\n#attachment_16691,\n#attachment_17141,\n#attachment_17329"},{"a":"#right-sidebar .widget_sp_image"},{"a":"#topleftAd,\n#toprightAd"},{"a":".adver_banner,\n.theiaStickySidebar .ml-slider"},{"a":".header-subscription"},{"a":".single_featured_slide"},{"a":"a[href*=\"waltonbd.com\"]"},{"a":"#homeads"},{"a":"div[class*=\" ad-slot-\"]"},{"a":".bannertopimg,\n.bannertopimg2"},{"a":".vc_custom_1546328500609"},{"a":".chand-before-content_5,\n.chand-widget,\n.widget_viral_advertisement"},{"a":".t-out-span"},{"a":".single_dtails img,\nfigure.wp-block-embed"},{"a":".banner-muni-add"},{"a":".d-flex,\niframe[style*=\"height: 90px\"]"},{"a":"div[class*=\"bnner\"]"},{"a":".ad-ticker-right,\n.entry-content [data-position]"},{"a":".yvdo"},{"a":".roadblockpopup,\n.seithigalad"},{"a":".zja"},{"a":".wpb_wrapper aside.widget_media_image"},{"a":".side-adv"},{"a":".code-block > img,\nfigure.wpb_wrapper"},{"a":".mySlideBox,\na[href*=\"?ref=\"]"},{"a":"a[target=\"_blank\"] > img"},{"a":".header_adv"},{"a":"#widget_sp_image-3,\n#widget_sp_image-7,\n.bwp_gallery,\n.sidebar-right"},{"a":"#thumbs,\n.add_inner_news,\n.news-add"},{"a":".logoright"},{"a":"#module_03_ads300x250"}];

const hostnamesMap = new Map([["dailynewsj.online",0],["massnews.online",1],["metroplus.online",2],["muznews.online",3],["newshunter.online",4],["newswings.online",5],["steelcity.online",6],["up80.online",7],["emulyankan.org",8],["janamsakshi.org",9],["khabrainabhitak.org",10],["krishakjagat.org",11],["nagarprabha.org",12],["nbs24.org",13],["radiobihani.org",14],["sathyadeepam.org",15],["valvainews.org",16],["changetv.press",17],["chandrikadaily.qa",18],["notebook.today",19],["ab71.tv",20],["abcnepal.tv",21],["dbcnews.tv",22],["livetimes.tv",23],["news24bd.tv",24],["news71bangla.tv",25],["ns7.tv",26],["probashibangla.tv",27],["ptcnews.tv",28],["sagarmatha.tv",29],["samajbad.tv",30],["somoynews.tv",31],["sylheterjanapad.tv",32],["banglapost.co.uk",33],["despardesweekly.co.uk",34],["europemalayali.co.uk",35],["weeklydesh.co.uk",36],["tharunaya.us",37]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
