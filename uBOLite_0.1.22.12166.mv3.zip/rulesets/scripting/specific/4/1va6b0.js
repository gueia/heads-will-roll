/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecific() {

/******************************************************************************/

// vie-1

const argsList = [{"a":"#invideo_wrapper,\n#pc-catfixx,\n.Ads,\n.mobile-catfixx,\ndiv.Dvr-300,\ndiv[style^=\"position: fixed; top: 60px\"]"},{"a":"#adsTopInPageBanner,\n#popup,\n.adsContainer"},{"a":"iframe:nth-of-type(2)"},{"a":"#wrapper>div[style=\"text-align: center;\"]"},{"a":".banner-sticky-footer-ad,\n.container>center"},{"a":"#footer_fixed_ads"},{"a":"div.text-center:nth-of-type(7),\ndiv[style=\"min-height: 250px\"]"},{"a":"#top-banner-pc,\n.lixitt"},{"a":".button-ads-header,\n.main-carousel-wrapper,\n.top-bookies,\n.tvc-link-ads-full"},{"a":"div[data-value=\"1\"]"},{"a":"#headwrap>.computer,\n#headwrap>.mobile,\n.pc-catfix"},{"a":".footer-button-sign-in.hide-desk,\n.hide-desk.wrap-content>.wrap-btn-action,\n.menu-right-slide"},{"a":".firstmessfloadright.samItem,\n.my_nonresponsive_ads,\n.my_responsive_ads,\n.samBannerUnit,\n.samTextUnit"},{"a":".align-items-center.justify-content-between.d-flex.col-12>.d-lg-none.d-block,\n.btn-odds,\n.btno-group.d-none.d-lg-flex,\n.company,\n.container>.mt-1,\n.container>.mt-3,\n.d-lg-block,\n.justify-content-between.d-lg-none.d-flex.btno-group,\n.menu-item>a[rel=\"nofollow\"],\n.topButton,\n.widget_offer,\nheader>.container"},{"a":"#wap_bottombanner_content,\ndiv[id^=\"dnn_\"]"},{"a":"#bnc1"},{"a":"#bnc0"},{"a":".widget_media_image.widget_block.widget,\nimg.wp-image-1283,\nimg.wp-image-1285"},{"a":"#match-child-1,\n#quangcaopc,\n.banner-link,\n.block-catfish.text-center.d-lg-none.d-block,\n.container.mt-1,\n.container>ul,\n.d-lg-flex.d-none.sub-menu,\n.logo-cnt>.d-lg-none.d-block,\n.menu-cuoc-one88,\n.menu-top-nha-cai,\n.mt-5.d-lg-none.d-block.pb-2.text-center,\n.offer,\n.pl-lg-0.col-xl-4,\n.row.d-none,\n.sk_balloon,\n.widget-offers__list,\na.btn-odds[rel=\"nofollow\"],\ndiv.d-lg-none.d-block:nth-of-type(3)"},{"a":"#custom_html-45,\n#menu-menu li:nth-child(1n+7)"},{"a":".widget_custom_html.widget.widget_text"},{"a":"div.container:nth-of-type(5)"},{"a":"#itro_popup"},{"a":".banner-top-box"},{"a":"#position_full_top_banner_pc,\n.window_popup"},{"a":"#newmenu + div>div[style]"},{"a":".great-a-banner,\n.great-b-banner,\n.heart-banner"},{"a":".button-dangkyngay"},{"a":".afw-topbanner"},{"a":"#adm-slot-7234"},{"a":".ads_full"},{"a":".adv-section"},{"a":".left-right-banner"},{"a":"#banner3double"},{"a":".box-ads-bar"},{"a":".advertise,\n.main-ad-wrapper"},{"a":"div[id^=\"adsWeb\"]"},{"a":"#div_inpage_banner,\n#div_inpage_banner_open"},{"a":"#article-sidebar"},{"a":"#mbtfloat,\n#mfloat,\n#pop_banner,\n.BT-Ads,\n.qc-inner,\ndiv.qc_M_Chap_Middle,\ndiv.qc_TC_Chap_Middle,\ndiv[id^=\"qc_M_\"]"},{"a":"div[style*=\"position: fixed\"]"},{"a":".bgadmtoptotal"},{"a":".bannertop"},{"a":".top-right-col-ads"},{"a":".my_responsive_add,\n.titleBar + *,\n[class1=\"my_responsive_add\"]"},{"a":"#csnplayerads,\n.detail_lyric_1 div[style=\"text-align: right;\"]"},{"a":"#background_bg_link,\n#maiContent>div>div.colLt>aside,\n.bnr,\n.cate-24h-foot-box-adv-view-news > .row > .col-6:first-child,\nDIV[class=\"banner-LR\"],\ndiv.pos-rel:has(a[rel=\"nofollow sponsored\"])"},{"a":".admicro,\n.notad"},{"a":".top-header"},{"a":"#onefootball,\n.top_page"},{"a":"img.error"},{"a":"#subiz_wrapper,\n.ad-embed"},{"a":".features-r"},{"a":"#bannerMasthead,\n#desktop-home-top-page,\n#dta_inpage_wrapper,\n#dtads_inpage_wrapper,\n#mobile-home-middle-1,\n#mobile-home-middle-2,\n#mobile-home-top-page,\n#mobile-top-page"},{"a":".widget_media_image.widget"},{"a":".banner-cs"},{"a":".banner-top-main,\n.baohaiquan_bottom_970x250"},{"a":".top-advertisment"},{"a":"._ning_outer"},{"a":"#Adsv,\n.right-banner>a[title]"},{"a":".__ads_click"},{"a":"#BannerAdv"},{"a":"#gallery-2,\n.hd-cate-wrap,\n.home-qc-wrap,\n.home-sec-right .widget_media_image,\n.noname-left"},{"a":".columns-widget .col-right"},{"a":".Advs_adv-components__1nBNS.Advs_adv-300x250__2eyhC.Advs_no-content__RWwW2,\n.HotTagGlobal_fixed-height__1f50i"},{"a":".box_ads_d"},{"a":".exp_qc_share"},{"a":".c-banner"},{"a":".warp-banner-vip"},{"a":".sidebar>div[style]"},{"a":"#div-ub-docbao"},{"a":"#ouibounce-modal,\ndiv[id^=\"adsbg\"]"},{"a":"#widget-12"},{"a":"#widget-11,\n#widget-16,\n.mainContent>a[rel]"},{"a":".banr-Rt,\n.banrpstn"},{"a":"#myElementz,\n.bannerinfooter"},{"a":".LRBanner"},{"a":".bg_allpopupss,\n.bgal_popndungalal,\n.bn1,\n.bn2,\n.box_baiviet_dexuat,\n.box_quangcao_mobile_320x50,\n.box_text_qc"},{"a":"#tubia"},{"a":"#admzone57"},{"a":".ads-right1,\n.adv-row"},{"a":".adx-zone,\n.underlay"},{"a":".khw-ads-wrapper.clearfix"},{"a":"#qcRight,\n.banner-advertisements"},{"a":".banner-bottom-menu,\n.popup-bg,\n.showpop,\n[href*=\"bit.ly\"]"},{"a":".qc-benphai,\n.qc-bentrai"},{"a":"[class^=\"size\"]"},{"a":"#adrightsecondx,\n#adrightspecial,\n#adrightspeciallinks,\n#adsrighttop,\n#adsuggestion"},{"a":".advertTop,\n.hsdn > li:has(.adsbygoogle),\n.module_plugins"},{"a":".notice-content"},{"a":".khw-adk14-wrapper"},{"a":"[id^=\"adv\"]"},{"a":".quang_cao_pc_right_hoc_tap"},{"a":".advHolder"},{"a":".ads_shortcode"},{"a":".entry>a[target=\"_blank\"],\n[href*=\"hnmac.vn\"],\n[href*=\"laptopvang.com\"],\n[href*=\"macbookgiasi.vn\"],\n[href*=\"macone.vn\"],\n[href*=\"vender.vn\"]"},{"a":".admicro_top"},{"a":"#tdi_129"},{"a":".sponsor-zone"},{"a":"div[id^=\"ads_\"]"},{"a":"#box-affiliate"},{"a":"#top-adv"},{"a":".bannerchuyenmuc,\n.show-qc-home,\n.show_qc"},{"a":".baseHtml.noticeContent"},{"a":"#popup_center"},{"a":"div[style=\"text-align:center;margin-top:0px;margin-bottom:0px;\"]"},{"a":".banner-ads-home,\n.banner-in"},{"a":"div[class^=\"adv-\"]"},{"a":".ads-970x280"},{"a":"#mobi-top,\n#pc-top,\n.d-flex.justify-content-between>div>div.d-flex.justify-content-around.mt-4"},{"a":"#myCarousel,\n.banner-boder-zoom"},{"a":".modal-di__button-wrapper,\n.sam-slot"},{"a":"[id^=\"admzone\"]"},{"a":".ads-general-banner"},{"a":".LeftFloatBanner,\n.RightFloatBanner,\n.ads_top_left"},{"a":".block:has(.block-container > .block-body > a[href]),\n.block:has(.block-container > .block-body > ins)"},{"a":"div[class$=\"_ads\"],\ndiv[data-id=\"2\"]"},{"a":".ads_660x90,\n[class^=\"ads_\"]"},{"a":".bannerTOP1,\n.pc.bannerAuto"},{"a":"div[id^=\"adsMobile\"]"},{"a":".fyi"},{"a":".ads-common-box"},{"a":".p-body-pageContent>table[style=\"width:100%;display:inline-block;background: #fff;\"]"},{"a":".in-article-promo,\n.jsx-3569995709,\n.micro,\n.middle-comment-promotion,\n.pro-container,\n.promo-container,\ndiv[style=\"width:300px;height:250px\"],\ndiv[style=\"width:300px;height:600px\"],\ndiv[style=\"width:320px;height:100px\"]"},{"a":".container .desktopjszone,\n.mobilejszone"},{"a":"#header-ads-full,\n.ads-responsive,\n[id^=\"ads-\"]"},{"a":"#admbackground,\n#adsMainFooter,\n.Mobile_Masthead_TTO_Wrapper,\n.adm-bot"},{"a":".clearfix.adregion,\n.visible-md.header-banners"},{"a":".bannerqc,\n[class^=\"sticky-top\"],\n[href*=\"/default/template/\"],\n[href*=\"hungthinhcorp.com.vn\"],\n[href*=\"vietcombank.com.vn\"]"},{"a":".Flagrow-Ads-under-header"},{"a":".vfs_banner"},{"a":"#headerProxy,\n.rightleftads"},{"a":".box-adv,\n.mb-20.col-right-ads,\n.vmcadszone"},{"a":".zone--ad"},{"a":"section.mar20:nth-of-type(2),\nsection.mar20:nth-of-type(4)"},{"a":"#banner-dai-bottom,\n#banner-dai-top"},{"a":".v-element>.v-responsive,\ndiv.message--post"},{"a":".ads-top-wrap"},{"a":".bf-3-primary-column-size.bs-vc-sidebar-column.vc_col-sm-3.vc_column_container.bs-vc-column.wpb_column>.wpb_wrapper.bs-vc-wrapper"},{"a":".wrapper-adv"},{"a":"#banner1ab,\n#banner2ab"},{"a":".ad_by_yellowpages,\n.banner_add"},{"a":"#site-header"},{"a":"#ballon_right"},{"a":".notMsg.Sticky,\na[href^=\"https://one88.vn/vi/\"]"},{"a":".btm_banner"},{"a":".pre-pc-b91.preload-b91.preload"},{"a":".logo-partner"},{"a":".odds-button,\n.odds-button2"},{"a":"a[href^=\"//mage98rquewz.com/\"]"}];

const hostnamesMap = new Map([["animevietsub.pro",0],["ophim.pro",1],["dongphimtv.top",2],["tvhay.top",3],["7chill.tv",4],["dongphims.tv",5],["hhhkungfu.tv",6],["hhtq.tv",7],["khomuc6.tv",8],["phim33.tv",9],["phimgif.tv",10],["rakhoi8.tv",11],["thiendia99.tv",12],["vebo6.tv",[13,14]],["xoilac21.tv",[14,18]],["vieclam.tv",[15,16]],["xskt.com.vn",16],["vietphims.tv",17],["bongdaso.vin",19],["bimbim.vip",20],["phimhay24h.vip",21],["phimmoi.vip",22],["24hmoney.vn",23],["2banh.vn",24],["2game.vn",25],["5giay.vn",26],["blog.abit.vn",27],["afamily.vn",28],["sport5.vn",28],["m.afamily.vn",29],["antt.vn",30],["aoe.vn",[31,32]],["gametv.vn",[32,80]],["autodaily.vn",33],["xehay.vn",[33,140]],["baodansinh.vn",34],["baodauthau.vn",[35,36]],["tienphong.vn",[36,119,120]],["baogiaothong.vn",37],["baophapluat.vn",38],["blogtruyen.vn",39],["m.blogtruyen.vn",40],["cafebiz.vn",41],["cafef.vn",42],["ttvn.toquoc.vn",42],["careerlink.vn",43],["chap.vn",44],["chiasenhac.vn",45],["24h.com.vn",46],["autopro.com.vn",47],["baohaugiang.com.vn",48],["bongda.com.vn",49],["centralland.com.vn",50],["congan.com.vn",51],["daklak24h.com.vn",52],["dantri.com.vn",53],["ecci.com.vn",54],["fptshop.com.vn",55],["haiquanonline.com.vn",56],["nld.com.vn",57],["tapchikientruc.com.vn",58],["thanhtra.com.vn",59],["thoidai.com.vn",60],["petrotimes.vn",60],["thuongtruong.com.vn",61],["thuysanvietnam.com.vn",62],["trithuc24h.com.vn",63],["voh.com.vn",64],["congluan.vn",[65,66]],["giadinhonline.vn",66],["nongnghiep.vn",66],["congly.vn",67],["dangtinbatdongsan.vn",68],["realty.vn",[68,106]],["danviet.vn",69],["docbao.vn",70],["download.vn",71],["gamevui.vn",[71,81]],["kienthucykhoa.edu.vn",72],["plus.edu.vn",73],["eva.vn",74],["fshare.vn",75],["game24h.vn",76],["game8.vn",77],["gameio.vn",78],["gamek.vn",79],["genk.vn",82],["giaoducthoidai.vn",83],["vnews.gov.vn",84],["plus.gtv.vn",85],["helpex.vn",86],["hoatieu.vn",87],["hosocongty.vn",88],["hrspring.vn",89],["kenh14.vn",90],["kinhtedothi.vn",91],["minhngoc.net.vn",91],["vn-z.vn",91],["zingnews.vn",[91,142]],["lazi.vn",92],["luatvietnam.vn",93],["lucloi.vn",94],["maclife.vn",95],["muare.vn",96],["muaxegiatot.vn",97],["kienthuc.net.vn",98],["phunumoi.net.vn",99],["nhipcaudautu.vn",99],["nghesiviet.vn",100],["nhacdj.vn",101],["nhatrangclub.vn",[102,103]],["raovatbienhoa.vn",103],["olug.vn",104],["phapluatplus.vn",105],["reatimes.vn",107],["rung.vn",108],["saostar.vn",109],["sharecode.vn",110],["softonic.vn",111],["soha.vn",112],["startalk.vn",113],["stockbiz.vn",114],["techrum.vn",115],["thethao247.vn",116],["thethaovanhoa.vn",117],["thitruongtaichinhtiente.vn",118],["tinnhanhchungkhoan.vn",120],["tiin.vn",121],["timdaily.vn",122],["tinhte.vn",123],["tintucvietnam.vn",124],["truyenfull.vn",125],["tuoitre.vn",126],["tuyengiao.vn",127],["tvphapluat.vn",128],["v4u.vn",129],["vietfones.vn",130],["vietnamgsm.vn",131],["vietnamnet.vn",132],["vietnamplus.vn",133],["vietq.vn",134],["viettelstore.vn",135],["voz.vn",136],["vtvgiaitri.vn",137],["vungoctuan.vn",138],["webthethao.vn",139],["yellowpages.vn",141],["truyenqk.work",143],["cbox.ws",144],["animeweb.xyz",145],["javhiv.xyz",146],["feb.onedaysales.xyz",147],["plvb.xyz",148],["sexdiaryz.xyz",149]]);

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
const styles = [];
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            styles.push(details.a);
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

if ( styles.length === 0 ) { return; }

try {
    const sheet = new CSSStyleSheet();
    sheet.replace(`@layer{${styles.join(',')}{display:none!important;}}`);
    document.adoptedStyleSheets = [
        ...document.adoptedStyleSheets,
        sheet
    ];
} catch(ex) {
}

/******************************************************************************/

})();

/******************************************************************************/
