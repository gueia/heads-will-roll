/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecificEntityImport() {

/******************************************************************************/

// jpn-1

const argsList = [{"a":"#custom_html-2,#custom_html-4,.ads-above-single-player"},{"a":".ads-system,.cactus-sidebar-content > .widget_text:not(.style-5)"},{"a":".AdContainer"},{"a":"#right-side > div.side-box > div.side-title:first-child,.open"},{"a":"div[style^=\"max-width: 1000px;\"],div[style^=\"width: 300px; height: 250px\"],div[style^=\"width: 728px; height: 90px\"]"},{"a":".amazontotalboxtest"},{"a":".amazon-ranking-outer"},{"a":".ad__bit,div[class*=\"ad__container\"]"}];

const entitiesMap = new Map([["48idol",0],["9tsu",1],["fc2",2],["free-erobooks",3],["javmix",4],["matome-plus",5],["manga.okiba",6],["renote",7]]);

self.specificEntityImports = self.specificEntityImports || [];
self.specificEntityImports.push({ argsList, entitiesMap });

/******************************************************************************/

})();

/******************************************************************************/
