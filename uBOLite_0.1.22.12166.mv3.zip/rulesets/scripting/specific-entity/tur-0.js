/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecificEntityImport() {

/******************************************************************************/

// tur-0

const argsList = [{"a":"#advid > iframe + div[style^=\"display: block;\"][style*=\"position: absolute;\"][style*=\"z-index:\"]"},{"a":".footer-sticky"},{"a":"#sabit_reklam"},{"a":".rek-0,.rek-wrap > *:not(b),.right.floated > div[data-gets] > a[href][target=\"_blank\"] > img"},{"a":".adv.full-width.pull-left,.pull-right > div.box-sidebar,a[href][target=\"_blank\"] > img"},{"a":"#pageskin"},{"a":"#sticky,.close_page_skin,body .banner,div[data-tur^=\"ads\"]"},{"a":"#preRollBd,img[src^=\"https://finema-net.cdn.ampproject.org/\"]"},{"a":".rek-wrap"},{"a":".player-top-ad a"},{"a":".st_ad"},{"a":"#melbet,.col.pr-0 a[href][target=\"_blank\"] > img,.prevideo"},{"a":".btbg"},{"a":"a[href][target=\"_blank\"][rel=\"nofollow\"] > img"},{"a":"#footadskpt"},{"a":"#reki2,.ust-reklam"},{"a":".body-clickable"},{"a":".vidcontainer"},{"a":"#reki1"},{"a":"#mysite > div > a > img,.content-container > .fw_playerAlti[style]:empty,.content-container > div > a > img,.footerFixReklam,.footerKapat,.fw_anaRklm,.fw_footerFixed,.fw_headerRklm,.side-box > .fw_playerYaniKat2Ustu:empty,.ustheadreklam,div[style^=\"min-height:\"],iframe[src*=\"filmizletv.\"][src*=\"/sidrek.htm\"]"},{"a":".malker"},{"a":"#benzerler,#film > div[class*=\"-metin\"],#fixedreklam,#single_1_aciklama_alt,.adbetnetwork"},{"a":"a[href^=\"https://bit.ly/\"]"},{"a":".mst_ad"},{"a":".psk,.rekgec-div"},{"a":"#wrap a[target=\"_blank\"] > img"},{"a":"#footer-fixed,#vrklm,div[onclick^=\"event.preventDefault();window.open(\"]"},{"a":".card-money,.money-text,.rotorfon-top-indent,a[href^=\"https://bgel.moderjat.com/?partner\"]"},{"a":".money,.play-that-video a[target=\"_blank\"]"},{"a":".money--video,.money:not(.money--video),div[id^=\"reki\"]"},{"a":"#movie-sidebar > a[target=\"_blank\"],.row > div.container > div.table-container,.singleSag"},{"a":".ustrek"},{"a":".ad-right-area"},{"a":".menu_alti_reklam,.pageskin-top,.set-pageskin"},{"a":"#reki,body .ads-skin"},{"a":".sticky-footer-banner"},{"a":"#eazy_ad_unblocker_holder"},{"a":".add-inner,.video-ad-container"},{"a":"#iframe-reklam,.video-content > div[id^=\"welcomeDiv\"]"},{"a":"a[href^=\"https://accounts.binance.me/\"],iframe[src^=\"https://wlearnlounge.adsrv.eacdn.com/\"],img[alt=\"reklam\"]"},{"a":"#rek-container,*:not(.poster) > a[href][target=\"_blank\"] > img,a[href^=\"https://accounts.binance.com/tr/register\"],center > a[href][target=\"_blank\"],hr[style^=\"margin: 5px 0;\"][style*=\"border-color: #42e3d0;\"]"},{"a":".videoalt,.videoust"}];

const entitiesMap = new Map([["31vakti",0],["altyazilifilm",1],["fullhdizle",[1,22,26]],["canlitv",2],["dafflix",3],["dizibox",[4,5]],["hdfilmcehennemi2",[5,22,27,29]],["yabancidizi",[5,40]],["dizilab8",6],["dizilab9",6],["dizilla",7],["dizimov",8],["dizisup",[9,10]],["dizivap",[9,10]],["filmzal",[9,10,23]],["dizitime",[11,12,13]],["fullhdfilmizlesene",[12,24]],["fullhdfilmmodu",[12,18,25]],["filmyani",[13,22]],["diziyo",14],["setfilmizle",[14,22,33]],["elzemfilmizle",15],["enyenifilmizle",16],["filmizlesene",17],["filmizletv",[18,19]],["siyahfilmizle",[18,35]],["filmmakinesi",[20,21]],["filmmakinesi1",20],["hdfilmcehennemi",[27,28]],["jetfilmizle",30],["pifilmizle",31],["radyodinle",32],["sinepal",34],["torrentarsivi",36],["tranimeizle",37],["vipfilmlerizle",38],["webteizle",39],["yabancidizitv",41]]);

self.specificEntityImports = self.specificEntityImports || [];
self.specificEntityImports.push({ argsList, entitiesMap });

/******************************************************************************/

})();

/******************************************************************************/
