/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name css-specific.entity

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_cssSpecificEntityImport() {

/******************************************************************************/

// nor-0

const argsList = [{"a":".ad-min-height,.cc-top-ad-outer,.idle-timeout-outer,div[class$=\"-ad-container\"],td[class^=\"frame-shadow-\"]"},{"a":"#div-leeadsFullpageAd,.annons,.article-ad-container,.article-content > .code-block,.article-sponsored,.commercial-row,body[data-scrolling] .post-container-sponsored"},{"a":".AdContainer,div[class$=\"-top-advert\"]"},{"a":"#ad_mobiletopinsidetext,#ad_video,#bigVideoAd,#eventad,#sky2_1,.ad_smartphbig,.ad_video,.cocacola,.sponsor,.vast_ad_video,.videoContent > .clickTag,a[href*=\"/adclick.php\"],div[class^=\"ad300\"],div[style*=\"width:300px;height:600px;\"],div[style=\"min-height: 600px; margin-bottom: 20px;\"]"},{"a":"#cnsi ~ [jsaction*=\"dismiss\"]"},{"a":".text-center.mb-3"},{"a":".signad"},{"a":"form + div[style^=\"border-style:solid; \"]"},{"a":".type-provider.clearfix.flights"},{"a":"#footer_header,.adbox,.desktop-inline-ad,.outsider-ads"},{"a":"#GoogleAdsenseFooter + div[style^=\"width: 100%;\"],#crosslistingLauritzAdsenseBanner,#lauritzListingView,#leaderBoardListingviewTop"},{"a":"div[id^=\"ad-slot-\"]"},{"a":".interaction-block"}];

const entitiesMap = new Map([["180",0],["ehandel",1],["eurosport",2],["gamereactor",3],["google",4],["intrafish",5],["kimbino",6],["manuall",7],["momondo",8],["prisjakt",9],["qxl",10],["ticketmaster",11],["viaplay",12]]);

self.specificEntityImports = self.specificEntityImports || [];
self.specificEntityImports.push({ argsList, entitiesMap });

/******************************************************************************/

})();

/******************************************************************************/
