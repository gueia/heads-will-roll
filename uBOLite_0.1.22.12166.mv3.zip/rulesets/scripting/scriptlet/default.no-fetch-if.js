/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-fetch-if

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noFetchIf() {

/******************************************************************************/

// default

const argsList = [{"a":["ads"]},{"a":["/^/"]},{"a":["player-feedback"]},{"a":["/conversion_async.js"]},{"a":["method:HEAD"]},{"a":["googlesyndication","method:HEAD"]},{"a":["adsbygoogle"]},{"a":["damoh.ani-stream.com"]},{"a":["/google|adpushup/"]},{"a":["zomap.de"]},{"a":["adsafeprotected"]},{"a":["google"]},{"a":["googlesyndication"]},{"a":["popunder"]},{"a":["/google|\\/ad.+\\.js/"]},{"a":["adsbygoogle.js"]},{"a":["pop"]},{"a":["snigelweb"]},{"a":["manager"]},{"a":["moonicorn.network"]},{"a":["ad"]},{"a":["cloudfront.net/?"]},{"a":["xhr0"]},{"a":["analytics"]},{"a":["wtg-ads"]},{"a":["adv"]},{"a":["doubleclick"]},{"a":["cloud"]},{"a":["/ads|doubleclick/"]},{"a":["dqst.pl"]},{"a":["/googlesyndication|uniconsent/"]},{"a":["googlesyndication.com"]},{"a":["ads."]},{"a":["imasdk"]},{"a":["adoto"]},{"a":["body:browser"]},{"a":["url:/^https:\\/\\/www\\.reddit\\.com$/ method:post"]},{"a":["body:/[\\w\\W]{700}/"]},{"a":["method:Post"]},{"a":["url:ipapi.co"]},{"a":["wpadmngr"]}];

const hostnamesMap = new Map([["allmusic.com",0],["investing.com",0],["mylivewallpapers.com",0],["softfully.com",0],["sekilastekno.com",0],["mangahost4.com",0],["key-hub.eu",0],["discoveryplus.in",0],["news-world24.com",0],["calculator-online.net",0],["tutorial.siberuang.com",0],["romania.bz",0],["desiflixindia.com",0],["insurance.iptvsetupguide.com",0],["dotabuff.com",0],["mcqmall.com",0],["nguontv.org",0],["apksafe.in",0],["spigotunlocked.org",0],["cizzyscripts.com",0],["clamor.pl",0],["one-tech.xyz",0],["ozulscans.com",0],["i-polls.com",0],["insurancevela.com",0],["plagiarismchecker.co",0],["noor-book.com",0],["viraluttarakhand.in",0],["skidrowreloaded.com",1],["filmisub.com",1],["gamedistribution.com",1],["player.glomex.com",2],["atresplayer.com",3],["mac2sell.net",4],["1001tracklists.com",4],["123films.cc",4],["rechub.tv",4],["game3rb.com",4],["1412.rest",4],["sixsave.com",4],["highload.to",4],["bowfile.com",[4,21]],["hdsport.biz",4],["dealsfinders.blog",4],["iphonechecker.herokuapp.com",4],["coloringpage.eu",4],["conocimientoshackers.com",4],["juegosdetiempolibre.org",4],["karaokegratis.com.ar",4],["mammaebambini.it",4],["riazor.org",4],["rinconpsicologia.com",4],["sempredirebanzai.it",4],["vectogravic.com",4],["androidacy.com",4],["freetohell.com",4],["muyinteresante.es",5],["leechpremium.link",6],["camcam.cc",6],["png.is",6],["nohat.cc",6],["kpopsea.com",6],["isi7.net",6],["hyipstats.net",6],["palixi.net",6],["howdy.id",6],["fastssh.com",6],["sshkit.com",6],["freecoursesonline.me",6],["audiodoceo.com",6],["audiotools.pro",6],["ani-stream.com",7],["smallseotools.com",8],["joyn.de",9],["tf1.fr",10],["exe.app",11],["freshi.site",11],["eio.io",11],["ufacw.com",11],["figurehunter.net",11],["toolss.net",12],["romadd.com",12],["dailynewstoknow.com",12],["blog-forall.com",12],["homeairquality.org",12],["techtrim.tech",12],["arhplyrics.in",12],["raky.in",12],["askpaccosi.com",12],["crypto4tun.com",12],["jpoplist.us",12],["quizack.com",12],["moddingzone.in",12],["rajsayt.xyz",12],["jaunpurmusic.info",12],["apkandroidhub.in",12],["babymodz.com",12],["deezloaded.com",12],["mad.gplpalace.one",12],["studyis.xyz",12],["worldappsstore.xyz",12],["prepostseo.com",12],["dulichkhanhhoa.net",12],["noithatmyphu.vn",12],["bitefaucet.com",12],["iptvjournal.com",12],["dramaworldhd.co",12],["tudaydeals.com",12],["choiceappstore.xyz",12],["inbbotlist.com",12],["freepreset.net",12],["cryptoblog24.info",12],["amritadrino.com",12],["wikitraveltips.com",12],["getintoway.com",12],["crdroid.net",12],["zerion.cc",12],["beelink.pro",12],["hax.co.id",12],["woiden.id",12],["pviewer.site",12],["theusaposts.com",12],["hackr.io",12],["camarchive.tv",13],["duplichecker.com",14],["hindustantimes.com",15],["makaveli.xyz",16],["falixnodes.net",17],["linkpoi.me",18],["platform.adex.network",19],["mcrypto.club",20],["coinsparty.com",20],["weszlo.com",20],["tinyurl.is",22],["wyze.com",23],["mmorpg.org.pl",24],["pinoyfaucet.com",25],["journaldemontreal.com",26],["tvanouvelles.ca",26],["boxingstreams100.com",26],["mlbstreams100.com",26],["mmastreams-100.tv",26],["nbastreams-100.tv",26],["soccerstreams-100.tv",26],["vods.tv",26],["weather.com",26],["speedrun.com",27],["dongknows.com",28],["forsal.pl",29],["photopea.com",30],["2the.space",31],["drakescans.com",32],["deutschekanale.com",33],["multifaucet.club",34],["manofadan.com",34],["search.brave.com",35],["reddit.com",36],["blog.skk.moe",[37,38]],["seazon.fr",39],["allcryptoz.net",40],["crewbase.net",40],["crewus.net",40],["shinbhu.net",40],["shinchu.net",40],["thumb8.net",40],["thumb9.net",40],["topcryptoz.net",40],["uniqueten.net",40],["ultraten.net",40]]);

/******************************************************************************/

const scriptlet = (
    conditions = ''
) => {
    const needles = [];
    for ( const condition of conditions.split(/\s+/) ) {
        if ( condition === '' ) { continue; }
        const pos = condition.indexOf(':');
        let key, value;
        if ( pos !== -1 ) {
            key = condition.slice(0, pos);
            value = condition.slice(pos + 1);
        } else {
            key = 'url';
            value = condition;
        }
        if ( value === '' ) {
            value = '^';
        } else if ( value.startsWith('/') && value.endsWith('/') ) {
            value = value.slice(1, -1);
        } else {
            value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }
        needles.push({ key, re: new RegExp(value) });
    }
    self.fetch = new Proxy(self.fetch, {
        apply: function(target, thisArg, args) {
            let proceed = true;
            try {
                let details;
                if ( args[0] instanceof self.Request ) {
                    details = args[0];
                } else {
                    details = Object.assign({ url: args[0] }, args[1]);
                }
                const props = new Map();
                for ( const prop in details ) {
                    let v = details[prop];
                    if ( typeof v !== 'string' ) {
                        try { v = JSON.stringify(v); }
                        catch(ex) { }
                    }
                    if ( typeof v !== 'string' ) { continue; }
                    props.set(prop, v);
                }
                proceed = needles.length === 0;
                for ( const { key, re } of needles ) {
                    if (
                        props.has(key) === false ||
                        re.test(props.get(key)) === false
                    ) {
                        proceed = true;
                        break;
                    }
                }
            } catch(ex) {
            }
            return proceed
                ? Reflect.apply(target, thisArg, args)
                : Promise.resolve(new Response());
        }
    });
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

