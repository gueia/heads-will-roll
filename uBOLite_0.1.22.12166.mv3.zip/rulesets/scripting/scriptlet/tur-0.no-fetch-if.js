/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-fetch-if

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noFetchIf() {

/******************************************************************************/

// tur-0

const argsList = [{"a":["www3.doubleclick.net"]},{"a":["pagead2.googlesyndication.com"]}];

const hostnamesMap = new Map([["bikifi.com",0],["ogznet.com",1],["discordsunucu.com",1],["boxofficeturkiye.com",1],["nedir.org",1],["puhutv.com",1],["dizipal1.cloud",1],["dizipal2.cloud",1],["dizipal3.cloud",1],["dizipal4.cloud",1],["dizipal5.cloud",1],["dizipal6.cloud",1],["dizipal7.cloud",1],["dizipal8.cloud",1],["dizipal9.cloud",1],["dizipal10.cloud",1],["dizipal11.cloud",1],["dizipal12.cloud",1],["dizipal13.cloud",1],["dizipal14.cloud",1],["dizipal15.cloud",1],["dizipal16.cloud",1],["dizipal17.cloud",1],["dizipal18.cloud",1],["dizipal19.cloud",1],["dizipal20.cloud",1],["dizipal21.cloud",1],["dizipal22.cloud",1],["dizipal23.cloud",1],["dizipal24.cloud",1],["dizipal25.cloud",1],["dizipal26.cloud",1],["dizipal27.cloud",1],["dizipal28.cloud",1],["dizipal29.cloud",1],["dizipal30.cloud",1],["dizipal31.cloud",1],["dizipal32.cloud",1],["dizipal33.cloud",1],["dizipal34.cloud",1],["dizipal35.cloud",1],["dizipal36.cloud",1],["dizipal37.cloud",1],["dizipal38.cloud",1],["dizipal39.cloud",1],["dizipal40.cloud",1],["dizipal41.cloud",1],["dizipal42.cloud",1],["dizipal43.cloud",1],["dizipal44.cloud",1],["dizipal45.cloud",1],["dizipal46.cloud",1],["dizipal47.cloud",1],["dizipal48.cloud",1],["dizipal49.cloud",1],["dizipal50.cloud",1],["dizipal51.cloud",1],["dizipal52.cloud",1],["dizipal53.cloud",1],["dizipal54.cloud",1],["dizipal55.cloud",1],["dizipal56.cloud",1],["dizipal57.cloud",1],["dizipal58.cloud",1],["dizipal59.cloud",1],["dizipal60.cloud",1],["dizipal61.cloud",1],["dizipal62.cloud",1],["dizipal63.cloud",1],["dizipal64.cloud",1],["dizipal65.cloud",1],["dizipal66.cloud",1],["dizipal67.cloud",1],["dizipal68.cloud",1],["dizipal69.cloud",1],["dizipal70.cloud",1],["dizipal71.cloud",1],["dizipal72.cloud",1],["dizipal73.cloud",1],["dizipal74.cloud",1],["dizipal75.cloud",1],["dizipal76.cloud",1],["dizipal77.cloud",1],["dizipal78.cloud",1],["dizipal79.cloud",1],["dizipal80.cloud",1],["dizipal81.cloud",1],["dizipal82.cloud",1],["dizipal83.cloud",1],["dizipal84.cloud",1],["dizipal85.cloud",1],["dizipal86.cloud",1],["dizipal87.cloud",1],["dizipal88.cloud",1],["dizipal89.cloud",1],["dizipal90.cloud",1],["dizipal91.cloud",1],["dizipal92.cloud",1],["dizipal93.cloud",1],["dizipal94.cloud",1],["dizipal95.cloud",1],["dizipal96.cloud",1],["dizipal97.cloud",1],["dizipal98.cloud",1],["dizipal99.cloud",1],["dizipal100.cloud",1],["dizipal101.cloud",1],["dizipal102.cloud",1],["dizipal103.cloud",1],["dizipal104.cloud",1],["dizipal105.cloud",1],["dizipal106.cloud",1],["dizipal107.cloud",1],["dizipal108.cloud",1],["dizipal109.cloud",1],["dizipal110.cloud",1],["dizipal111.cloud",1],["dizipal112.cloud",1],["dizipal113.cloud",1],["dizipal114.cloud",1],["dizipal115.cloud",1],["dizipal116.cloud",1],["dizipal117.cloud",1],["dizipal118.cloud",1],["dizipal119.cloud",1],["dizipal120.cloud",1],["dizipal121.cloud",1],["dizipal122.cloud",1],["dizipal123.cloud",1],["dizipal124.cloud",1],["dizipal125.cloud",1],["dizipal126.cloud",1],["dizipal127.cloud",1],["dizipal128.cloud",1],["dizipal129.cloud",1],["dizipal130.cloud",1],["dizipal131.cloud",1],["dizipal132.cloud",1],["dizipal133.cloud",1],["dizipal134.cloud",1],["dizipal135.cloud",1],["dizipal136.cloud",1],["dizipal137.cloud",1],["dizipal138.cloud",1],["dizipal139.cloud",1],["dizipal140.cloud",1],["dizipal141.cloud",1],["dizipal142.cloud",1],["dizipal143.cloud",1],["dizipal144.cloud",1],["dizipal145.cloud",1],["dizipal146.cloud",1],["dizipal147.cloud",1],["dizipal148.cloud",1],["dizipal149.cloud",1],["dizipal150.cloud",1],["dizipal151.cloud",1],["dizipal152.cloud",1],["dizipal153.cloud",1],["dizipal154.cloud",1],["dizipal155.cloud",1],["dizipal156.cloud",1],["dizipal157.cloud",1],["dizipal158.cloud",1],["dizipal159.cloud",1],["dizipal160.cloud",1],["dizipal161.cloud",1],["dizipal162.cloud",1],["dizipal163.cloud",1],["dizipal164.cloud",1],["dizipal165.cloud",1],["dizipal166.cloud",1],["dizipal167.cloud",1],["dizipal168.cloud",1],["dizipal169.cloud",1],["dizipal170.cloud",1],["dizipal171.cloud",1],["dizipal172.cloud",1],["dizipal173.cloud",1],["dizipal174.cloud",1],["dizipal175.cloud",1],["dizipal176.cloud",1],["dizipal177.cloud",1],["dizipal178.cloud",1],["dizipal179.cloud",1],["dizipal180.cloud",1],["dizipal181.cloud",1],["dizipal182.cloud",1],["dizipal183.cloud",1],["dizipal184.cloud",1],["dizipal185.cloud",1],["dizipal186.cloud",1],["dizipal187.cloud",1],["dizipal188.cloud",1],["dizipal189.cloud",1],["dizipal190.cloud",1],["dizipal191.cloud",1],["dizipal192.cloud",1],["dizipal193.cloud",1],["dizipal194.cloud",1],["dizipal195.cloud",1],["dizipal196.cloud",1],["dizipal197.cloud",1],["dizipal198.cloud",1],["dizipal199.cloud",1],["dizipal200.cloud",1],["dizipal400.com",1],["dizipal401.com",1],["dizipal402.com",1],["dizipal403.com",1],["dizipal404.com",1],["dizipal405.com",1],["dizipal406.com",1],["dizipal407.com",1],["dizipal408.com",1],["dizipal409.com",1],["dizipal410.com",1],["dizipal411.com",1],["dizipal412.com",1],["dizipal413.com",1],["dizipal414.com",1],["dizipal415.com",1],["dizipal416.com",1],["dizipal417.com",1],["dizipal418.com",1],["dizipal419.com",1],["dizipal420.com",1],["dizipal421.com",1],["dizipal422.com",1],["dizipal423.com",1],["dizipal424.com",1],["dizipal425.com",1],["dizipal426.com",1],["dizipal427.com",1],["dizipal428.com",1],["dizipal429.com",1],["dizipal430.com",1],["dizipal431.com",1],["dizipal432.com",1],["dizipal433.com",1],["dizipal434.com",1],["dizipal435.com",1],["dizipal436.com",1],["dizipal437.com",1],["dizipal438.com",1],["dizipal439.com",1],["dizipal440.com",1],["dizipal441.com",1],["dizipal442.com",1],["dizipal443.com",1],["dizipal444.com",1],["dizipal445.com",1],["dizipal446.com",1],["dizipal447.com",1],["dizipal448.com",1],["dizipal449.com",1],["dizipal450.com",1],["dizipal451.com",1],["dizipal452.com",1],["dizipal453.com",1],["dizipal454.com",1],["dizipal455.com",1],["dizipal456.com",1],["dizipal457.com",1],["dizipal458.com",1],["dizipal459.com",1],["dizipal460.com",1],["dizipal461.com",1],["dizipal462.com",1],["dizipal463.com",1],["dizipal464.com",1],["dizipal465.com",1],["dizipal466.com",1],["dizipal467.com",1],["dizipal468.com",1],["dizipal469.com",1],["dizipal470.com",1],["dizipal471.com",1],["dizipal472.com",1],["dizipal473.com",1],["dizipal474.com",1],["dizipal475.com",1],["dizipal476.com",1],["dizipal477.com",1],["dizipal478.com",1],["dizipal479.com",1],["dizipal480.com",1],["dizipal481.com",1],["dizipal482.com",1],["dizipal483.com",1],["dizipal484.com",1],["dizipal485.com",1],["dizipal486.com",1],["dizipal487.com",1],["dizipal488.com",1],["dizipal489.com",1],["dizipal490.com",1],["dizipal491.com",1],["dizipal492.com",1],["dizipal493.com",1],["dizipal494.com",1],["dizipal495.com",1],["dizipal496.com",1],["dizipal497.com",1],["dizipal498.com",1],["dizipal499.com",1],["dizipal500.com",1],["dizipal501.com",1],["dizipal502.com",1],["dizipal503.com",1],["dizipal504.com",1],["dizipal505.com",1],["dizipal506.com",1],["dizipal507.com",1],["dizipal508.com",1],["dizipal509.com",1],["dizipal510.com",1],["dizipal511.com",1],["dizipal512.com",1],["dizipal513.com",1],["dizipal514.com",1],["dizipal515.com",1],["dizipal516.com",1],["dizipal517.com",1],["dizipal518.com",1],["dizipal519.com",1],["dizipal520.com",1],["dizipal521.com",1],["dizipal522.com",1],["dizipal523.com",1],["dizipal524.com",1],["dizipal525.com",1],["dizipal526.com",1],["dizipal527.com",1],["dizipal528.com",1],["dizipal529.com",1],["dizipal530.com",1],["dizipal531.com",1],["dizipal532.com",1],["dizipal533.com",1],["dizipal534.com",1],["dizipal535.com",1],["dizipal536.com",1],["dizipal537.com",1],["dizipal538.com",1],["dizipal539.com",1],["dizipal540.com",1],["dizipal541.com",1],["dizipal542.com",1],["dizipal543.com",1],["dizipal544.com",1],["dizipal545.com",1],["dizipal546.com",1],["dizipal547.com",1],["dizipal548.com",1],["dizipal549.com",1],["dizipal550.com",1]]);

/******************************************************************************/

const scriptlet = (
    conditions = ''
) => {
    const needles = [];
    for ( const condition of conditions.split(/\s+/) ) {
        if ( condition === '' ) { continue; }
        const pos = condition.indexOf(':');
        let key, value;
        if ( pos !== -1 ) {
            key = condition.slice(0, pos);
            value = condition.slice(pos + 1);
        } else {
            key = 'url';
            value = condition;
        }
        if ( value === '' ) {
            value = '^';
        } else if ( value.startsWith('/') && value.endsWith('/') ) {
            value = value.slice(1, -1);
        } else {
            value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }
        needles.push({ key, re: new RegExp(value) });
    }
    self.fetch = new Proxy(self.fetch, {
        apply: function(target, thisArg, args) {
            let proceed = true;
            try {
                let details;
                if ( args[0] instanceof self.Request ) {
                    details = args[0];
                } else {
                    details = Object.assign({ url: args[0] }, args[1]);
                }
                const props = new Map();
                for ( const prop in details ) {
                    let v = details[prop];
                    if ( typeof v !== 'string' ) {
                        try { v = JSON.stringify(v); }
                        catch(ex) { }
                    }
                    if ( typeof v !== 'string' ) { continue; }
                    props.set(prop, v);
                }
                proceed = needles.length === 0;
                for ( const { key, re } of needles ) {
                    if (
                        props.has(key) === false ||
                        re.test(props.get(key)) === false
                    ) {
                        proceed = true;
                        break;
                    }
                }
            } catch(ex) {
            }
            return proceed
                ? Reflect.apply(target, thisArg, args)
                : Promise.resolve(new Response());
        }
    });
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

