/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name no-xhr-if

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_noXhrIf() {

/******************************************************************************/

// default

const argsList = [{"a":["request=adb"]},{"a":["doubleclick"]},{"a":["ads"]},{"a":["adsbygoogle"]},{"a":["homad-global-configs"]},{"a":["/doubleclick|googlesyndication/"]},{"a":["ad_"]},{"a":["/\\/ad\\/g\\/1/"]},{"a":["svonm"]},{"a":["/\\/VisitorAPI\\.js|\\/AppMeasurement\\.js/"]},{"a":["googlesyndication"]},{"a":["damoh"]},{"a":["/youboranqs01|spotx/"]},{"a":["pop"]},{"a":["/^/"]},{"a":["/ad"]},{"a":["prebid"]},{"a":["securepubads"]},{"a":["wpadmngr"]},{"a":["url:googlesyndication"]},{"a":["/js/prebid-"]},{"a":["/analytics|livestats/"]},{"a":["mahimeta"]},{"a":["notifier"]},{"a":["/ad-"]},{"a":["/coinzillatag|czilladx/"]},{"a":["php"]},{"a":["popunder"]},{"a":["adx"]},{"a":["cls_report?"]},{"a":["method:POST url:/logImpressions"]},{"a":["method:POST url:/^https:\\/\\/www\\.reddit\\.com$/"]},{"a":["method:POST"]},{"a":["cloudflare.com/cdn-cgi/trace"]},{"a":["amazonaws"]},{"a":["/recommendations."]},{"a":["/api/analytics"]},{"a":["api"]}];

const hostnamesMap = new Map([["handelsblatt.com",0],["moviepilot.de",1],["sbs.com.au",1],["minhaconexao.com.br",1],["meteoetradar.com",1],["gala.fr",1],["gearingcommander.com",2],["duplichecker.com",2],["novelmultiverse.com",2],["taming.io",2],["snlookup.com",2],["globfone.com",2],["chimicamo.org",2],["webforefront.com",2],["cinemakottaga.top",2],["apkmagic.com.ar",2],["reaperscans.id",2],["pinsystem.co.uk",3],["texture-packs.com",3],["manyakan.com",3],["persianhive.com",3],["boainformacao.com.br",3],["privatenewz.com",3],["gcertificationcourse.com",3],["portaliz.site",3],["ghior.com",3],["tech-story.net",3],["visalist.io",3],["wetter.de",4],["gnomio.com",5],["frkn64modding.com",6],["channel4.com",7],["vox.de",8],["vip.de",8],["rtl.de",8],["fitforfun.de",8],["nationalgeographic.fr",9],["freegogpcgames.com",10],["informaxonline.com",[10,15]],["gaminplay.com",10],["blisseyhusband.in",10],["cinemakottaga.ml",10],["mhdtvworld.xyz",10],["routech.ro",10],["rontechtips.com",10],["homeairquality.org",10],["techtrim.tech",10],["pigeonburger.xyz",10],["freedownloadvideo.net",10],["askpaccosi.com",10],["crypto4tun.com",10],["fusedgt.com",10],["apkowner.org",10],["appsmodz.com",10],["bingotingo.com",10],["superpsx.com",10],["financeflix.in",10],["technoflip.in",10],["paidappstore.xyz",10],["stringreveals.com",10],["fox.com",10],["obutecodanet.ig.com.br",10],["firmwarex.net",10],["softwaretotal.net",10],["nawahi1.com",10],["freecodezilla.net",10],["movieslegacy.com",10],["rbxscripts.net",10],["comentariodetexto.com",10],["wordpredia.com",10],["karanpc.com",10],["autobild.de",11],["computerbild.de",11],["golem.de",11],["desired.de",11],["t-online.de",11],["stern.de",11],["familie.de",11],["tvnow.de",11],["kino.de",11],["spieletipps.de",11],["rakuten.tv",12],["zdam.xyz",13],["atozmath.com",14],["pasend.link",14],["freewp.io",14],["jetpunk.com",16],["falixnodes.net",17],["mcrypto.club",18],["coinsparty.com",18],["stardeos.com",19],["tvwish.com",20],["goduke.com",21],["1apple.xyz",22],["lavanguardia.com",23],["foodsdictionary.co.il",24],["freesolana.top",25],["farescd.com",26],["freebinance.top",27],["freelitecoin.top",28],["freetron.top",28],["citi.com",29],["docs.google.com",30],["reddit.com",31],["endbasic.dev",32],["jmmv.dev",32],["myair2.resmed.com",33],["travelerdoor.com",33],["bestiefy.com",34],["azby.fmworld.net",35],["unrealengine.com",36],["wco.tv",37]]);

/******************************************************************************/

const scriptlet = (
    conditions = ''
) => {
    const xhrInstances = new WeakMap();
    const needles = [];
    for ( const condition of conditions.split(/\s+/) ) {
        if ( condition === '' ) { continue; }
        const pos = condition.indexOf(':');
        let key, value;
        if ( pos !== -1 ) {
            key = condition.slice(0, pos);
            value = condition.slice(pos + 1);
        } else {
            key = 'url';
            value = condition;
        }
        if ( value === '' ) {
            value = '^';
        } else if ( value.startsWith('/') && value.endsWith('/') ) {
            value = value.slice(1, -1);
        } else {
            value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }
        needles.push({ key, re: new RegExp(value) });
    }
    self.XMLHttpRequest = class extends self.XMLHttpRequest {
        open(...args) {
            const argNames = [ 'method', 'url' ];
            const haystack = new Map();
            for ( let i = 0; i < args.length && i < argNames.length; i++  ) {
                haystack.set(argNames[i], args[i]);
            }
            if ( haystack.size !== 0 ) {
                let matches = true;
                for ( const { key, re } of needles ) {
                    matches = re.test(haystack.get(key) || '');
                    if ( matches === false ) { break; }
                }
                if ( matches ) {
                    xhrInstances.set(this, haystack);
                }
            }
            return super.open(...args);
        }
        send(...args) {
            const haystack = xhrInstances.get(this);
            if ( haystack === undefined ) {
                return super.send(...args);
            }
            Object.defineProperties(this, {
                readyState: { value: 4, writable: false },
                response: { value: '', writable: false },
                responseText: { value: '', writable: false },
                responseURL: { value: haystack.get('url'), writable: false },
                responseXML: { value: '', writable: false },
                status: { value: 200, writable: false },
                statusText: { value: 'OK', writable: false },
            });
            this.dispatchEvent(new Event('readystatechange'));
            this.dispatchEvent(new Event('load'));
            this.dispatchEvent(new Event('loadend'));
        }
    };
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/

