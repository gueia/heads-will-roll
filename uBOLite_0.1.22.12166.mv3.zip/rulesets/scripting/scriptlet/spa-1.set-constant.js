/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name set-constant
/// alias set

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_setConstant() {

/******************************************************************************/

// spa-1

const argsList = [{"a":["eazy_ad_unblocker_msg_var","''"]},{"a":["antiAdBlockerStyle","noopFunc"]},{"a":["Object.prototype.adblockerEnabled","false"]},{"a":["adsbygoogle.loaded","true"]},{"a":["adBlockCheck","true"]},{"a":["pp_show_popupmessage","noopFunc"]},{"a":["easySettings.adblock","0"]},{"a":["canRunAds","true"]},{"a":["onload","null"]},{"a":["adblockDetector.init","noopFunc"]},{"a":["adsbygoogle.length","undefined"]},{"a":["WSL2.config.enableAdblockEcommerce","0"]},{"a":["ads_unblocked","true"]},{"a":["adblock","true"]},{"a":["kkwoiNI","noopFunc"]},{"a":["yUIlOsT","noopFunc"]},{"a":["better_ads_adblock","true"]},{"a":["adBlockDetected","false"]},{"a":["isAdsDisplayed","true"]},{"a":["Lata","1"]},{"a":["loadingAds","true"]},{"a":["goog_pvsid","1"]},{"a":["Goog_Osd_UnloadAdBlock","1"]},{"a":["google_osd_loaded","1"]},{"a":["stopMan","false"]},{"a":["google_unique_id","1"]},{"a":["googleIMState","emptyObj"]},{"a":["player.preroll","noopFunc"]},{"a":["anunciotag","noopFunc"]},{"a":["_mvnxp","noopFunc"]},{"a":["loadingAds","undefined"]},{"a":["click","1"]},{"a":["clickd","1"]},{"a":["xxxStore","undefined"]},{"a":["vidorev_jav_plugin_video_ads_object.vid_ads_m_video_ads","''"]},{"a":["clicked","true"]},{"a":["eClicked","true"]},{"a":["number","0"]},{"a":["sync","true"]},{"a":["a_consola","noopFunc"]}];

const hostnamesMap = new Map([["legendei.net",0],["mangacrab.com",1],["cadenaser.com",2],["texto.kom.gt",3],["infojobs.com.br",4],["maringapost.com.br",5],["bandab.com.br",5],["ouniversodatv.com",6],["skynovels.net",7],["wuolah.com",7],["botinnifit.com",7],["minhasdelicias.com",7],["luchaonline.com",7],["tribunaavila.com",8],["deportealdia.live",9],["elquintobeatle.com",10],["empregoestagios.com",10],["satcesc.com",10],["applesfera.com",11],["bebesymas.com",11],["compradiccion.com",11],["diariodelviajero.com",11],["directoalpaladar.com",11],["elblogsalmon.com",11],["espinof.com",11],["genbeta.com",11],["motorpasion.com",11],["motorpasionmoto.com",11],["pymesyautonomos.com",11],["trendencias.com",11],["trendenciashombre.com",11],["vidaextra.com",11],["vitonica.com",11],["xataka.com",11],["xatakaciencia.com",11],["xatakafoto.com",11],["xatakahome.com",11],["xatakamovil.com",11],["xatakandroid.com",11],["xatakawindows.com",11],["doceru.com",12],["docero.com.br",12],["comandotorrents.org",13],["mangahost.site",[14,15]],["adslayuda.com",16],["outerspace.com.br",17],["doramasmp4.com",18],["file4go.net",19],["seriesdonghua.com",20],["mundodonghua.com",20],["mangahost4.com",[21,22,23,24,25,26]],["mangahosted.com",[21,22,23,24,25,26]],["mangahost2.com",[21,22,23,24,25,26]],["mangahost1.com",26],["mangahostbr.net",26],["mangahostbr.com",26],["player.hentaistube.com",27],["playnewserie.xyz",28],["vizer.vip",29],["tiohentai.xyz",30],["otakustv.com",[31,32]],["pornolandia.xxx",33],["hentaiporno.xxx",34],["megadescarga.net",[35,36,37,38]],["fakings.com",39]]);

/******************************************************************************/

const scriptlet = (
    chain = '',
    cValue = ''
) => {
    if ( chain === '' ) { return; }
    if ( cValue === 'undefined' ) {
        cValue = undefined;
    } else if ( cValue === 'false' ) {
        cValue = false;
    } else if ( cValue === 'true' ) {
        cValue = true;
    } else if ( cValue === 'null' ) {
        cValue = null;
    } else if ( cValue === "''" ) {
        cValue = '';
    } else if ( cValue === '[]' ) {
        cValue = [];
    } else if ( cValue === '{}' ) {
        cValue = {};
    } else if ( cValue === 'noopFunc' ) {
        cValue = function(){};
    } else if ( cValue === 'trueFunc' ) {
        cValue = function(){ return true; };
    } else if ( cValue === 'falseFunc' ) {
        cValue = function(){ return false; };
    } else if ( /^\d+$/.test(cValue) ) {
        cValue = parseFloat(cValue);
        if ( isNaN(cValue) ) { return; }
        if ( Math.abs(cValue) > 0x7FFF ) { return; }
    } else {
        return;
    }
    let aborted = false;
    const mustAbort = function(v) {
        if ( aborted ) { return true; }
        aborted =
            (v !== undefined && v !== null) &&
            (cValue !== undefined && cValue !== null) &&
            (typeof v !== typeof cValue);
        return aborted;
    };
    // https://github.com/uBlockOrigin/uBlock-issues/issues/156
    //   Support multiple trappers for the same property.
    const trapProp = function(owner, prop, configurable, handler) {
        if ( handler.init(owner[prop]) === false ) { return; }
        const odesc = Object.getOwnPropertyDescriptor(owner, prop);
        let prevGetter, prevSetter;
        if ( odesc instanceof Object ) {
            owner[prop] = cValue;
            if ( odesc.get instanceof Function ) {
                prevGetter = odesc.get;
            }
            if ( odesc.set instanceof Function ) {
                prevSetter = odesc.set;
            }
        }
        try {
            Object.defineProperty(owner, prop, {
                configurable,
                get() {
                    if ( prevGetter !== undefined ) {
                        prevGetter();
                    }
                    return handler.getter(); // cValue
                },
                set(a) {
                    if ( prevSetter !== undefined ) {
                        prevSetter(a);
                    }
                    handler.setter(a);
                }
            });
        } catch(ex) {
        }
    };
    const trapChain = function(owner, chain) {
        const pos = chain.indexOf('.');
        if ( pos === -1 ) {
            trapProp(owner, chain, false, {
                v: undefined,
                init: function(v) {
                    if ( mustAbort(v) ) { return false; }
                    this.v = v;
                    return true;
                },
                getter: function() {
                    return cValue;
                },
                setter: function(a) {
                    if ( mustAbort(a) === false ) { return; }
                    cValue = a;
                }
            });
            return;
        }
        const prop = chain.slice(0, pos);
        const v = owner[prop];
        chain = chain.slice(pos + 1);
        if ( v instanceof Object || typeof v === 'object' && v !== null ) {
            trapChain(v, chain);
            return;
        }
        trapProp(owner, prop, true, {
            v: undefined,
            init: function(v) {
                this.v = v;
                return true;
            },
            getter: function() {
                return this.v;
            },
            setter: function(a) {
                this.v = a;
                if ( a instanceof Object ) {
                    trapChain(a, chain);
                }
            }
        });
    };
    trapChain(window, chain);
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
