/*******************************************************************************

    uBlock Origin - a browser extension to block requests.
    Copyright (C) 2019-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    The scriptlets below are meant to be injected only into a
    web page context.
*/

/* jshint esversion:11 */

'use strict';

/******************************************************************************/

/// name abort-current-script
/// alias acs
/// alias abort-current-inline-script
/// alias acis

/******************************************************************************/

// Important!
// Isolate from global scope
(function uBOL_abortCurrentScript() {

/******************************************************************************/

// rus-0

const argsList = [{"a":["$","1xbet"]},{"a":["$","append"]},{"a":["$","contextmenu"]},{"a":["$","divWrapper"]},{"a":["$","get"]},{"a":["$","init_x_place"]},{"a":["$","mainContainer"]},{"a":["JSON.parse"]},{"a":["JSON.parse","atob"]},{"a":["Math.floor","adregain_wall"]},{"a":["Math.random"]},{"a":["Object.defineProperty","rcBuf"]},{"a":["String.fromCharCode","var _0x"]},{"a":["XMLHttpRequest","document.querySelectorAll"]},{"a":["__require","/clickunder/"]},{"a":["addEventListener","DOMContentLoaded"],"n":["new.fastpic.org"]},{"a":["atob","void"]},{"a":["clickExplorer"]},{"a":["decodeURIComponent","/63cc63/"]},{"a":["decodeURIComponent","fromCharCode"]},{"a":["decodeURIComponent","getAdBlockStatus"]},{"a":["disableSelection","reEnable"]},{"a":["document.addEventListener","adsBlocked"]},{"a":["document.createElement"]},{"a":["document.createElement","/ru-n4p|ua-n4p|загрузка.../"]},{"a":["document.createElement","ExternalChromePop"]},{"a":["document.createElement","Math.random"],"n":["new.fastpic.org"]},{"a":["document.createElement","atob"]},{"a":["document.createElement","delete window"]},{"a":["document.getElementsByTagName","unselectable"]},{"a":["document.oncontextmenu"]},{"a":["document.onkeydown"]},{"a":["document.querySelector","/banner/"]},{"a":["document.querySelector","contentDocument"],"n":["new.fastpic.org"]},{"a":["encodeURIComponent","rcBuf"]},{"a":["fuckAdBlock","undefined"]},{"a":["jQuery","backgroundImage"]},{"a":["redram","/загрузка.../"]},{"a":["setInterval","reload"]},{"a":["setTimeout","adblockwarn"]},{"a":["Math.floor","AdSense"]},{"a":["document.getElementById","composedPath"]},{"a":["document.querySelectorAll","popMagic"]}];

const hostnamesMap = new Map([["shaiba.kz",0],["budport.com.ua",1],["asn.in.ua",2],["penzainform.ru",3],["l2top.ru",4],["tut.by",5],["conversion.im",6],["freescreens.ru",7],["imgbase.ru",7],["imgcach.ru",7],["imgclick.ru",7],["payforpic.ru",7],["picclick.ru",7],["picclock.ru",7],["picforall.ru",7],["fenglish.site",8],["mp3spy.cc",8],["electric-house.ru",9],["euro-football.ru",9],["forums.rusmedserv.com",9],["liveresult.ru",9],["smolensk-auto.ru",9],["smolensk-auto.site",9],["stroi-help.ru",9],["tenews.org.ua",[10,24]],["agroreview.com",[11,34]],["dc-marvel.org",12],["gidonline.eu",12],["filmisub.com",[13,19]],["kinofen.net",[13,19]],["gdespaces.com",14],["gdespaces.net",14],["spac.me",14],["spac1.com",14],["spac1.info",14],["spac1.me",14],["spac1.net",14],["spac1.org",14],["spac1.ru",14],["spaces-blogs.com",14],["spaces.im",14],["spcs.me",14],["spcs.news",14],["spcs.social",14],["strip2.in",14],["strip2.xxx",14],["fastpic.org",[15,26,33]],["allboxing.ru",16],["pravvest.ru",17],["daz3d.ru",18],["dynamo.kiev.ua",[20,32]],["epravda.com.ua",[20,32]],["football.ua",[20,32]],["isport.ua",[20,32]],["liga.net",[20,24,32]],["pravda.com.ua",[20,32]],["www.i.ua",[20,32]],["my-expert.ru",[21,29,30]],["mod-wot.ru",22],["krolik.biz",23],["1news.com.ua",24],["365news.biz",24],["4mama.ua",24],["4studio.com.ua",24],["7days-ua.com",24],["agroter.com.ua",24],["alter-science.info",24],["apnews.com.ua",24],["argumentiru.com",24],["asiaplustj.info",24],["autotema.org.ua",24],["autotheme.info",24],["beauty.ua",24],["begemot-media.com",24],["begemot.media",24],["chas.cv.ua",24],["cheline.com.ua",24],["cikavosti.com",24],["ck.ua",24],["cn.ua",24],["comments.ua",24],["cvnews.cv.ua",24],["day.kyiv.ua",24],["depo.ua",24],["dnews.dn.ua",24],["dv-gazeta.info",24],["dyvys.info",24],["economistua.com",24],["edinstvennaya.ua",24],["ekovolga.com",24],["expert.in.ua",24],["fedpress.ru",24],["firtka.if.ua",24],["forpost.media",24],["fraza.com",24],["glavnoe.ua",24],["glavnoe24.ru",24],["glavpost.ua",24],["golosinfo.com.ua",24],["gorodkiev.com.ua",24],["gov.ua",24],["grad.ua",24],["greenpost.ua",24],["ifnews.org.ua",24],["inforpost.com",24],["inkorr.com",24],["itechua.com",24],["iz.com.ua",24],["kh.ua",24],["khersonline.net",24],["kolizhanka.com.ua",24],["kop.net.ua",24],["kr.ua",24],["krymr.com",24],["kurskcity.ru",24],["lvnews.org.ua",24],["mega-music.pro",24],["mi100.info",24],["mignews.com.ua",24],["mind.ua",24],["moirebenok.ua",24],["mycompplus.ru",24],["nakanune.ru",24],["narodna-pravda.ua",24],["nashbryansk.ru",24],["news24today.info",24],["newsua.one",24],["ngp-ua.info",24],["nnews.com.ua",24],["novavlada.info",24],["novynarnia.com",24],["np.pl.ua",24],["odessa-life.od.ua",24],["ogo.ua",24],["oukr.info",24],["panoptikon.org",24],["pg11.ru",24],["pik.net.ua",24],["pingvin.pro",24],["pl.com.ua",24],["planetanovosti.com",24],["podpricelom.com.ua",24],["politnavigator.net",24],["poltava365.com",24],["portal.lviv.ua",24],["praktika-vlasti.com.ua",24],["prm.ua",24],["procherk.info",24],["profootball.ua",24],["promin.cv.ua",24],["radiosvoboda.org",24],["ratel.kz",24],["real-vin.com",24],["reporter.ua",24],["risu.ua",24],["rivne.media",24],["rivnenews.com.ua",24],["rusjev.net",24],["russianshowbiz.info",24],["rv.ua",24],["rvnews.rv.ua",24],["semobile.com.ua",24],["showdream.org",24],["sport-kr.com.ua",24],["strana.news",24],["strana.today",24],["sud.ua",24],["te.ua",24],["telekritika.ua",24],["theageoffootball.com",24],["treebuna.info",24],["tverigrad.ru",24],["tverisport.ru",24],["tvoymalysh.com.ua",24],["uainfo.org",24],["uanews.org.ua",24],["uatv.ua",24],["ukranews.com",24],["ukrrain.com",24],["unn.com.ua",24],["vchaspik.ua",24],["versii.if.ua",24],["viva.ua",24],["vlast.kz",24],["vnn24.ru",24],["volnorez.com.ua",24],["volyninfa.com.ua",24],["volyninfo.com",24],["volynpost.com",24],["volynua.com",24],["vsviti.com.ua",24],["westnews.info",24],["womo.ua",24],["wworld.com.ua",24],["zbirna.com",24],["zp.ua",24],["rutor.in",25],["karpatnews.in.ua",26],["kaztorka.org",26],["kg-portal.ru",26],["nnm-club.lib",26],["nnm-club.me",26],["nnmclub.ro",26],["nnmclub.to",26],["shanson320.ru",27],["vesti.ua",27],["lrepacks.net",28],["brigadtv.ru",30],["castle-serial.ru",30],["ehlita.ru",30],["gameout.ru",30],["itevonklass.ru",30],["izmailovtv.xyz",30],["karateltv.ru",30],["lyucifer.tv",30],["m-z.tv",30],["pokazuha.ru",30],["samomdele.tv",30],["saske.tv",30],["sorvigolovatv.ru",30],["taynyeistiny.ru",30],["transformator220.ru",30],["stalker-mods.clan.su",31],["stalker-mods.su",31],["gwss.ru",35],["hardwareluxx.ru",36],["marieclaire.ua",37],["24boxing.com.ua",38],["bilshe.com",38],["businessua.com",38],["f1analytic.com",38],["football-ukraine.com",38],["footballgazeta.com",38],["footballtransfer.com.ua",38],["glianec.com",38],["nashamama.com",38],["sportanalytic.com",38],["stravy.net",38],["zdorovia.com.ua",38],["livesport.ws",39],["dmod.cc",40],["draug.ru",40],["modsforwot.ru",40],["skam.online",41],["pornopuk.com",42],["huyamba.tv",42],["piratam.net",42],["piratca.net",42],["porn720.biz",42],["sexitorrent.com",42],["sextor.org",42],["domahatv.com",42],["torrent-pirat.com",42],["xtorrent.net",42],["rapidzona.tv",42],["xxxrip.net",42],["xxxtor.com",42],["hentai-share.one",42]]);

/******************************************************************************/

// Issues to mind before changing anything:
//  https://github.com/uBlockOrigin/uBlock-issues/issues/2154

const scriptlet = (
    target = '',
    needle = '',
    context = ''
) => {
    if ( target === '' ) { return; }
    const reRegexEscape = /[.*+?^${}()|[\]\\]/g;
    const reNeedle = (( ) => {
        if ( needle === '' ) { return /^/; }
        if ( /^\/.+\/$/.test(needle) ) {
            return new RegExp(needle.slice(1,-1));
        }
        return new RegExp(needle.replace(reRegexEscape, '\\$&'));
    })();
    const reContext = (( ) => {
        if ( context === '' ) { return; }
        if ( /^\/.+\/$/.test(context) ) {
            return new RegExp(context.slice(1,-1));
        }
        return new RegExp(context.replace(reRegexEscape, '\\$&'));
    })();
    const chain = target.split('.');
    let owner = window;
    let prop;
    for (;;) {
        prop = chain.shift();
        if ( chain.length === 0 ) { break; }
        owner = owner[prop];
        if ( owner instanceof Object === false ) { return; }
    }
    let value;
    let desc = Object.getOwnPropertyDescriptor(owner, prop);
    if (
        desc instanceof Object === false ||
        desc.get instanceof Function === false
    ) {
        value = owner[prop];
        desc = undefined;
    }
    const magic = String.fromCharCode(Date.now() % 26 + 97) +
                  Math.floor(Math.random() * 982451653 + 982451653).toString(36);
    const scriptTexts = new WeakMap();
    const getScriptText = elem => {
        let text = elem.textContent;
        if ( text.trim() !== '' ) { return text; }
        if ( scriptTexts.has(elem) ) { return scriptTexts.get(elem); }
        const [ , mime, content ] =
            /^data:([^,]*),(.+)$/.exec(elem.src.trim()) ||
            [ '', '', '' ];
        try {
            switch ( true ) {
            case mime.endsWith(';base64'):
                text = self.atob(content);
                break;
            default:
                text = self.decodeURIComponent(content);
                break;
            }
        } catch(ex) {
        }
        scriptTexts.set(elem, text);
        return text;
    };
    const validate = ( ) => {
        const e = document.currentScript;
        if ( e instanceof HTMLScriptElement === false ) { return; }
        if ( reContext !== undefined && reContext.test(e.src) === false ) {
            return;
        }
        if ( reNeedle.test(getScriptText(e)) === false ) { return; }
        throw new ReferenceError(magic);
    };
    Object.defineProperty(owner, prop, {
        get: function() {
            validate();
            return desc instanceof Object
                ? desc.get.call(owner)
                : value;
        },
        set: function(a) {
            validate();
            if ( desc instanceof Object ) {
                desc.set.call(owner, a);
            } else {
                value = a;
            }
        }
    });
    const oe = window.onerror;
    window.onerror = function(msg) {
        if ( typeof msg === 'string' && msg.includes(magic) ) {
            return true;
        }
        if ( oe instanceof Function ) {
            return oe.apply(this, arguments);
        }
    }.bind();
};

/******************************************************************************/

let hn;
try { hn = document.location.hostname; } catch(ex) { }
while ( hn ) {
    if ( hostnamesMap.has(hn) ) {
        let argsIndices = hostnamesMap.get(hn);
        if ( typeof argsIndices === 'number' ) { argsIndices = [ argsIndices ]; }
        for ( const argsIndex of argsIndices ) {
            const details = argsList[argsIndex];
            if ( details.n && details.n.includes(hn) ) { continue; }
            try { scriptlet(...details.a); } catch(ex) {}
        }
    }
    if ( hn === '*' ) { break; }
    const pos = hn.indexOf('.');
    if ( pos !== -1 ) {
        hn = hn.slice(pos + 1);
    } else {
        hn = '*';
    }
}

argsList.length = 0;
hostnamesMap.clear();

/******************************************************************************/

})();

/******************************************************************************/
